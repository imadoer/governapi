'use client'

import { signIn } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { useEffect, useState } from 'react'

export default function LoginPage() {
  const router = useRouter()
  const [isMobile, setIsMobile] = useState(false)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    setIsMobile(window.innerWidth <= 768)
  }, [])

  const handleLogin = async () => {
    setLoading(true)
    try {
      const result = await signIn('credentials', {
        email: 'demo@governapi.com',
        password: 'demo123',
        redirect: false
      })
      
      if (result?.ok) {
        router.push('/dashboard')
      } else {
        console.error('Login failed')
        setLoading(false)
      }
    } catch (error) {
      console.error('Login error:', error)
      setLoading(false)
    }
  }

  const buttonText = loading ? 'Signing In...' : 'Enter Dashboard'

  if (isMobile) {
    return (
      <div dangerouslySetInnerHTML={{
        __html: `
          <div style="min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 20px; background-color: #f5f5f5; font-family: -apple-system, BlinkMacSystemFont, sans-serif;">
            <div style="width: 100%; max-width: 400px; background: white; padding: 40px 30px; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); text-align: center;">
              <h1 style="font-size: 28px; font-weight: bold; margin: 0 0 10px 0; color: #1a1a1a;">GovernAPI</h1>
              <p style="color: #666; margin: 0 0 30px 0; font-size: 16px;">Enterprise API Governance Platform</p>
              <button onclick="window.location.reload()" style="width: 100%; padding: 16px; background-color: #1677ff; color: white; border: none; border-radius: 6px; font-size: 16px; font-weight: 500; cursor: pointer;">
                Enter Dashboard
              </button>
              <div style="margin-top: 20px; font-size: 14px; color: #999;">Demo Platform</div>
            </div>
          </div>
        `
      }} />
    )
  }

  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '20px',
      backgroundColor: '#f5f5f5',
      fontFamily: '-apple-system, BlinkMacSystemFont, sans-serif'
    }}>
      <div style={{
        width: '100%',
        maxWidth: '400px',
        backgroundColor: 'white',
        padding: '40px 30px',
        borderRadius: '8px',
        boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
        textAlign: 'center'
      }}>
        <h1 style={{ fontSize: '28px', fontWeight: 'bold', margin: '0 0 10px 0', color: '#1a1a1a' }}>
          GovernAPI
        </h1>
        <p style={{ color: '#666', margin: '0 0 30px 0', fontSize: '16px' }}>
          Enterprise API Governance Platform
        </p>
        <button 
          onClick={handleLogin} 
          disabled={loading}
          style={{
            width: '100%',
            padding: '16px',
            backgroundColor: loading ? '#ccc' : '#1677ff',
            color: 'white',
            border: 'none',
            borderRadius: '6px',
            fontSize: '16px',
            fontWeight: '500',
            cursor: loading ? 'not-allowed' : 'pointer'
          }}
        >
          {buttonText}
        </button>
        <div style={{ marginTop: '20px', fontSize: '14px', color: '#999' }}>
          Demo Platform
        </div>
      </div>
    </div>
  )
}
