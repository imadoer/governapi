'use client'

import { useState, useEffect } from 'react'
import { 
  Button, Card, Table, Tag, Space, Row, Col, Statistic, Layout, Menu,
  Avatar, Dropdown, Progress, Alert, Select, DatePicker, Badge, Tooltip,
  Typography, Divider, Tabs, Timeline, Modal, Form, Input, message
} from 'antd'
import { 
  PlusOutlined, CloudOutlined, SecurityScanOutlined, CheckCircleOutlined,
  SyncOutlined, WarningOutlined, UserOutlined, LogoutOutlined, SettingOutlined,
  DashboardOutlined, ClockCircleOutlined, ExclamationCircleOutlined,
  FilterOutlined, DownloadOutlined, ReloadOutlined, ApiOutlined,
  BellOutlined, QuestionCircleOutlined, SearchOutlined, MenuFoldOutlined,
  MenuUnfoldOutlined, ProjectOutlined, FileTextOutlined, TeamOutlined,
  GlobalOutlined, DollarOutlined, LineChartOutlined, SafetyCertificateOutlined,
  AuditOutlined, RiseOutlined, FallOutlined
} from '@ant-design/icons'
import { useRouter } from 'next/navigation'
import { AddAPIModal } from './components/AddAPIModal'
import { CreatePolicyModal } from './components/CreatePolicyModal'
import { handleGenerateReport, handleViolationAction } from './actions'

const { Header, Content, Sider } = Layout
const { Title, Text } = Typography
const { RangePicker } = DatePicker
const { TabPane } = Tabs

export default function DashboardPage() {
  const router = useRouter()
  const [collapsed, setCollapsed] = useState(false)
  const [scanModalVisible, setScanModalVisible] = useState(false)
  const [addAPIModalVisible, setAddAPIModalVisible] = useState(false)
  const [createPolicyModalVisible, setCreatePolicyModalVisible] = useState(false)
  const [loading, setLoading] = useState(false)
  const [activeTab, setActiveTab] = useState('overview')
  
  // Real data states
  const [scanHistory, setScanHistory] = useState<any[]>([])
  const [apiList, setApiList] = useState<any[]>([])
  const [policyList, setPolicyList] = useState<any[]>([])
  const [violations, setViolations] = useState<any[]>([])
