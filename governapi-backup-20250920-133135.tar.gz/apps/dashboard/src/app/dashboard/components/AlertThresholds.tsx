'use client'

import { Card, Form, InputNumber, Switch, Button, message, Row, Col, Divider } from 'antd'
import { useState, useEffect } from 'react'

export function AlertThresholds() {
  const [form] = Form.useForm()
  const [loading, setLoading] = useState(false)
  const [config, setConfig] = useState(null)

  useEffect(() => {
    fetchConfig()
  }, [])

  const fetchConfig = async () => {
    try {
      const response = await fetch('https://governapi.com/api/alert-config')
      const data = await response.json()
      setConfig(data.config)
      form.setFieldsValue(data.config)
    } catch (error) {
      console.error('Failed to fetch alert config:', error)
    }
  }

  const handleSave = async (values) => {
    setLoading(true)
    try {
      const response = await fetch('https://governapi.com/api/alert-config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ config: values })
      })
      
      if (response.ok) {
        message.success('Alert configuration saved successfully')
        setConfig(values)
      } else {
        message.error('Failed to save configuration')
      }
    } catch (error) {
      message.error('Error saving configuration')
    }
    setLoading(false)
  }

  return (
    <Card title="Alert Threshold Configuration">
      <Form
        form={form}
        layout="vertical"
        onFinish={handleSave}
        initialValues={config}
      >
        <Row gutter={16}>
          <Col span={12}>
            <h4>Vulnerability Thresholds</h4>
            <Form.Item
              label="Critical Vulnerabilities"
              name={['webhook_triggers', 'critical_threshold']}
              help="Trigger alert when this many CRITICAL vulnerabilities are found"
            >
              <InputNumber min={0} max={10} />
            </Form.Item>
            
            <Form.Item
              label="High Vulnerabilities"
              name={['webhook_triggers', 'high_threshold']}
              help="Trigger alert when this many HIGH vulnerabilities are found"
            >
              <InputNumber min={0} max={20} />
            </Form.Item>
            
            <Form.Item
              label="Medium Vulnerabilities"
              name={['webhook_triggers', 'medium_threshold']}
              help="Trigger alert when this many MEDIUM vulnerabilities are found"
            >
              <InputNumber min={0} max={50} />
            </Form.Item>
          </Col>
          
          <Col span={12}>
            <h4>Performance Thresholds</h4>
            <Form.Item
              label="Response Time Threshold (ms)"
              name={['webhook_triggers', 'response_time_threshold']}
              help="Trigger alert when response time exceeds this value"
            >
              <InputNumber min={1000} max={30000} step={1000} />
            </Form.Item>
            
            <Divider />
            
            <h4>Notification Settings</h4>
            <Form.Item
              label="Enable Notifications"
              name={['notification_settings', 'enabled']}
              valuePropName="checked"
            >
              <Switch />
            </Form.Item>
            
            <Form.Item
              label="Include Performance Data"
              name={['notification_settings', 'include_performance']}
              valuePropName="checked"
            >
              <Switch />
            </Form.Item>
            
            <Form.Item
              label="Include OWASP Details"
              name={['notification_settings', 'include_owasp_details']}
              valuePropName="checked"
            >
              <Switch />
            </Form.Item>
          </Col>
        </Row>
        
        <Form.Item>
          <Button type="primary" htmlType="submit" loading={loading}>
            Save Configuration
          </Button>
        </Form.Item>
      </Form>
      
      {config && (
        <div style={{ marginTop: 16, padding: 16, backgroundColor: '#f5f5f5', borderRadius: 4 }}>
          <h4>Current Thresholds:</h4>
          <p>Critical: {config.webhook_triggers?.critical_threshold} | High: {config.webhook_triggers?.high_threshold} | Medium: {config.webhook_triggers?.medium_threshold}</p>
          <p>Response Time: {config.webhook_triggers?.response_time_threshold}ms</p>
        </div>
      )}
    </Card>
  )
}
