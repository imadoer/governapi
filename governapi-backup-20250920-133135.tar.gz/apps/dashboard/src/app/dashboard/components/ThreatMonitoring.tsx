'use client'

import { Card, Table, Tag, Statistic, Row, Col, Button, message } from 'antd'
import { useState, useEffect } from 'react'

export function ThreatMonitoring() {
  const [threatData, setThreatData] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchThreatData()
    const interval = setInterval(fetchThreatData, 15000) // Refresh every 15 seconds
    return () => clearInterval(interval)
  }, [])

  const fetchThreatData = async () => {
    try {
      const response = await fetch('https://governapi.com/api/threat-monitoring')
      const data = await response.json()
      setThreatData(data)
    } catch (error) {
      console.error('Failed to fetch threat data:', error)
    }
    setLoading(false)
  }

  const unblockIP = async (ip) => {
    try {
      const response = await fetch('https://governapi.com/api/threat-monitoring/unblock', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ip })
      })

      if (response.ok) {
        message.success(`IP ${ip} unblocked successfully`)
        fetchThreatData()
      } else {
        message.error('Failed to unblock IP')
      }
    } catch (error) {
      message.error('Error unblocking IP')
    }
  }

  if (!threatData || !threatData.data) {
    return <Card loading={loading}>Loading threat data...</Card>
  }

  const blockedColumns = [
    {
      title: 'IP Address',
      dataIndex: 'ip',
      key: 'ip'
    },
    {
      title: 'Reason',
      dataIndex: 'reason',
      key: 'reason',
      render: (reason) => (
        <Tag color={reason.includes('CRITICAL') ? 'red' : reason.includes('HIGH') ? 'orange' : 'yellow'}>
          {reason}
        </Tag>
      )
    },
    {
      title: 'Remaining Time',
      dataIndex: 'remainingMs',
      key: 'remaining',
      render: (ms) => {
        const minutes = Math.ceil(ms / (1000 * 60))
        return `${minutes} minutes`
      }
    },
    {
      title: 'Action',
      key: 'action',
      render: (_, record) => (
        <Button size="small" onClick={() => unblockIP(record.ip)}>
          Unblock
        </Button>
      )
    }
  ]

  const recentThreatsColumns = [
    {
      title: 'Time',
      dataIndex: 'timestamp',
      key: 'timestamp',
      render: (timestamp) => new Date(timestamp).toLocaleTimeString()
    },
    {
      title: 'IP',
      dataIndex: 'ip',
      key: 'ip'
    },
    {
      title: 'Threat Level',
      dataIndex: 'threat_level',
      key: 'threat_level',
      render: (level) => (
        <Tag color={
          level === 'CRITICAL' ? 'red' :
          level === 'HIGH' ? 'orange' :
          level === 'MEDIUM' ? 'yellow' : 'green'
        }>
          {level}
        </Tag>
      )
    },
    {
      title: 'Threats',
      dataIndex: 'threats',
      key: 'threats',
      render: (threats) => threats?.slice(0, 2).join(', ') || 'None'
    },
    {
      title: 'Status',
      dataIndex: 'blocked',
      key: 'blocked',
      render: (blocked) => (
        <Tag color={blocked ? 'red' : 'blue'}>
          {blocked ? 'Blocked' : 'Allowed'}
        </Tag>
      )
    }
  ]

  return (
    <div>
      <Row gutter={[16, 16]} style={{ marginBottom: 16 }}>
        <Col span={6}>
          <Statistic
            title="Active Blocks"
            value={threatData.data.stats?.blockedIPs || 0}
            valueStyle={{ color: (threatData.data.stats?.blockedIPs || 0) > 0 ? '#ff4d4f' : '#52c41a' }}
          />
        </Col>
        <Col span={6}>
          <Statistic
            title="Threats Today"
            value={threatData.data.stats?.threatsToday || 0}
            valueStyle={{ color: (threatData.data.stats?.threatsToday || 0) > 10 ? '#ff4d4f' : '#faad14' }}
          />
        </Col>
        <Col span={6}>
          <Statistic
            title="Critical Blocks"
            value={threatData.data.stats?.criticalBlocks || 0}
            valueStyle={{ color: '#ff4d4f' }}
          />
        </Col>
        <Col span={6}>
          <Statistic
            title="Bot Detection Rate"
            value={`${threatData.data.stats?.botDetectionRate || 0}%`}
          />
        </Col>
      </Row>

      <Row gutter={[16, 16]}>
        <Col span={24}>
          <Card title="Currently Blocked IPs">
            <Table
              dataSource={threatData.data.blockedIPs || []}
              columns={blockedColumns}
              rowKey="ip"
              pagination={false}
              locale={{ emptyText: 'No blocked IPs - all clear!' }}
            />
          </Card>
        </Col>
      </Row>

      <Row gutter={[16, 16]} style={{ marginTop: 16 }}>
        <Col span={24}>
          <Card title="Recent Security Events">
            <Table
              dataSource={threatData.data.recentThreats || []}
              columns={recentThreatsColumns}
              rowKey={(record) => `${record.ip}-${record.timestamp}`}
              pagination={{ pageSize: 10 }}
            />
          </Card>
        </Col>
      </Row>

      <Row gutter={[16, 16]} style={{ marginTop: 16 }}>
        <Col span={12}>
          <Card title="Threat Patterns Detected Today">
            {threatData.data.threatPatterns && (
              <div>
                {Object.entries(threatData.data.threatPatterns).map(([pattern, count]) => (
                  <p key={pattern}>
                    <strong>{pattern.replace('_', ' ')}:</strong> {count} attempts
                  </p>
                ))}
              </div>
            )}
          </Card>
        </Col>

        <Col span={12}>
          <Card title="Security Recommendations">
            <div>
              <p><strong>Active Protection:</strong> {(threatData.data.stats?.blockedIPs || 0) > 0 ? '⚠️ Blocking threats' : '✅ All systems clear'}</p>
              <p><strong>Bot Activity:</strong> {(threatData.data.stats?.botDetectionRate || 0) > 50 ? '⚠️ High bot activity' : '✅ Normal activity'}</p>
              <p><strong>Threat Level:</strong> {(threatData.data.stats?.criticalBlocks || 0) > 0 ? '🔴 Critical threats detected' : '🟢 Low threat level'}</p>
            </div>
          </Card>
        </Col>
      </Row>
    </div>
  )
}
