'use client'

import { Card, Table, Button, Modal, Form, Input, Select, Tag, Space, message } from 'antd'
import { useState, useEffect } from 'react'
import { PlusOutlined, UserOutlined } from '@ant-design/icons'

export function UserManagement() {
  const [users, setUsers] = useState([])
  const [modalVisible, setModalVisible] = useState(false)
  const [loading, setLoading] = useState(false)
  const [form] = Form.useForm()

  useEffect(() => {
    fetchUsers()
  }, [])

  const fetchUsers = async () => {
    try {
      const response = await fetch('https://governapi.com/api/users')
      const data = await response.json()
      setUsers(data.users || [])
    } catch (error) {
      console.error('Failed to fetch users:', error)
    }
  }

  const handleCreateUser = async (values) => {
    setLoading(true)
    try {
      const response = await fetch('https://governapi.com/api/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(values)
      })
      
      if (response.ok) {
        message.success('User created successfully')
        setModalVisible(false)
        form.resetFields()
        fetchUsers()
      } else {
        message.error('Failed to create user')
      }
    } catch (error) {
      message.error('Error creating user')
    }
    setLoading(false)
  }

  const getRoleColor = (role) => {
    const colors = {
      admin: 'red',
      security_analyst: 'blue',
      auditor: 'orange',
      viewer: 'green'
    }
    return colors[role] || 'default'
  }

  const columns = [
    {
      title: 'User',
      dataIndex: 'name',
      render: (name, record) => (
        <Space>
          <UserOutlined />
          <div>
            <div>{name}</div>
            <div style={{ fontSize: '12px', color: '#666' }}>{record.email}</div>
          </div>
        </Space>
      )
    },
    {
      title: 'Role',
      dataIndex: 'role',
      render: (role) => (
        <Tag color={getRoleColor(role)}>
          {role.replace('_', ' ').toUpperCase()}
        </Tag>
      )
    },
    {
      title: 'Status',
      dataIndex: 'active',
      render: (active) => (
        <Tag color={active ? 'green' : 'red'}>
          {active ? 'Active' : 'Inactive'}
        </Tag>
      )
    },
    {
      title: 'Last Login',
      dataIndex: 'last_login',
      render: (date) => date === 'Never' ? date : new Date(date).toLocaleDateString()
    },
    {
      title: 'Created',
      dataIndex: 'created_at',
      render: (date) => new Date(date).toLocaleDateString()
    }
  ]

  return (
    <div>
      <Card 
        title="User Management" 
        extra={
          <Button 
            type="primary" 
            icon={<PlusOutlined />}
            onClick={() => setModalVisible(true)}
          >
            Add User
          </Button>
        }
      >
        <Table 
          dataSource={users}
          columns={columns}
          rowKey="id"
          pagination={{ pageSize: 10 }}
        />
      </Card>

      <Modal
        title="Create New User"
        open={modalVisible}
        onCancel={() => setModalVisible(false)}
        onOk={() => form.submit()}
        confirmLoading={loading}
      >
        <Form
          form={form}
          layout="vertical"
          onFinish={handleCreateUser}
        >
          <Form.Item
            label="Name"
            name="name"
            rules={[{ required: true, message: 'Please enter user name' }]}
          >
            <Input placeholder="John Doe" />
          </Form.Item>
          
          <Form.Item
            label="Email"
            name="email"
            rules={[
              { required: true, message: 'Please enter email' },
              { type: 'email', message: 'Please enter valid email' }
            ]}
          >
            <Input placeholder="john@company.com" />
          </Form.Item>
          
          <Form.Item
            label="Role"
            name="role"
            rules={[{ required: true, message: 'Please select a role' }]}
          >
            <Select placeholder="Select role">
              <Select.Option value="admin">Admin - Full access</Select.Option>
              <Select.Option value="security_analyst">Security Analyst - Scan & analyze</Select.Option>
              <Select.Option value="auditor">Auditor - View reports only</Select.Option>
              <Select.Option value="viewer">Viewer - Read-only access</Select.Option>
            </Select>
          </Form.Item>
        </Form>
      </Modal>
    </div>
  )
}
