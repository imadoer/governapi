'use client'

import { Card, Table, Button, Modal, Form, Input, Select, Tag, Space, message } from 'antd'
import { useState, useEffect } from 'react'
import { PlusOutlined, PlayCircleOutlined } from '@ant-design/icons'

export function ScheduledScanning() {
  const [scans, setScans] = useState([])
  const [modalVisible, setModalVisible] = useState(false)
  const [loading, setLoading] = useState(false)
  const [form] = Form.useForm()

  useEffect(() => {
    fetchScheduledScans()
  }, [])

  const fetchScheduledScans = async () => {
    try {
      const response = await fetch('https://governapi.com/api/scheduled-scans')
      const data = await response.json()
      setScans(data.scans || [])
    } catch (error) {
      console.error('Failed to fetch scheduled scans:', error)
    }
  }

  const handleCreateScan = async (values) => {
    setLoading(true)
    try {
      const response = await fetch('https://governapi.com/api/scheduled-scans', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(values)
      })
      
      if (response.ok) {
        message.success('Scheduled scan created successfully')
        setModalVisible(false)
        form.resetFields()
        fetchScheduledScans()
      } else {
        message.error('Failed to create scheduled scan')
      }
    } catch (error) {
      message.error('Error creating scheduled scan')
    }
    setLoading(false)
  }

  const executeScheduledScans = async () => {
    try {
      const response = await fetch('https://governapi.com/api/scheduled-scans/execute', {
        method: 'POST'
      })
      
      const result = await response.json()
      if (result.success) {
        message.success(`Executed ${result.total_executed} scheduled scans`)
        fetchScheduledScans()
      } else {
        message.error('Failed to execute scheduled scans')
      }
    } catch (error) {
      message.error('Error executing scheduled scans')
    }
  }

  const columns = [
    { title: 'Name', dataIndex: 'name' },
    { title: 'Target URL', dataIndex: 'target_url', render: (url) => url.substring(0, 50) + '...' },
    { 
      title: 'Frequency', 
      dataIndex: 'frequency',
      render: (freq) => <Tag color="blue">{freq.toUpperCase()}</Tag>
    },
    { 
      title: 'Status', 
      dataIndex: 'enabled',
      render: (enabled) => <Tag color={enabled ? 'green' : 'red'}>{enabled ? 'Active' : 'Disabled'}</Tag>
    },
    { 
      title: 'Last Run', 
      dataIndex: 'last_run',
      render: (date) => date ? new Date(date).toLocaleString() : 'Never'
    },
    { 
      title: 'Next Run', 
      dataIndex: 'next_run',
      render: (date) => new Date(date).toLocaleString()
    }
  ]

  return (
    <div>
      <Card 
        title="Scheduled Security Scans" 
        extra={
          <Space>
            <Button 
              icon={<PlayCircleOutlined />}
              onClick={executeScheduledScans}
            >
              Run Now
            </Button>
            <Button 
              type="primary" 
              icon={<PlusOutlined />}
              onClick={() => setModalVisible(true)}
            >
              Schedule Scan
            </Button>
          </Space>
        }
      >
        <Table 
          dataSource={scans}
          columns={columns}
          rowKey="id"
          pagination={{ pageSize: 10 }}
        />
      </Card>

      <Modal
        title="Schedule New Security Scan"
        open={modalVisible}
        onCancel={() => setModalVisible(false)}
        onOk={() => form.submit()}
        confirmLoading={loading}
      >
        <Form
          form={form}
          layout="vertical"
          onFinish={handleCreateScan}
        >
          <Form.Item
            label="Scan Name"
            name="name"
            rules={[{ required: true, message: 'Please enter scan name' }]}
          >
            <Input placeholder="Production API Security Scan" />
          </Form.Item>
          
          <Form.Item
            label="Target URL"
            name="target_url"
            rules={[
              { required: true, message: 'Please enter target URL' },
              { type: 'url', message: 'Please enter valid URL' }
            ]}
          >
            <Input placeholder="https://api.company.com" />
          </Form.Item>
          
          <Form.Item
            label="Frequency"
            name="frequency"
            rules={[{ required: true, message: 'Please select frequency' }]}
          >
            <Select placeholder="Select scan frequency">
              <Select.Option value="daily">Daily - Every 24 hours</Select.Option>
              <Select.Option value="weekly">Weekly - Every 7 days</Select.Option>
              <Select.Option value="monthly">Monthly - Every 30 days</Select.Option>
            </Select>
          </Form.Item>
        </Form>
      </Modal>
    </div>
  )
}
