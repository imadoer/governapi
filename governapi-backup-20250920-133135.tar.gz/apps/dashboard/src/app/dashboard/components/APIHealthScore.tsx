'use client'

import { Card, Progress, Row, Col, Statistic } from 'antd'
import { useState, useEffect } from 'react'

export function APIHealthScore() {
  const [healthData, setHealthData] = useState({
    overallHealth: 0,
    vulnerabilityCount: 0,
    criticalIssues: 0,
    riskLevel: 'UNKNOWN'
  })

  useEffect(() => {
    fetchHealthData()
  }, [])

  const fetchHealthData = async () => {
    try {
      const response = await fetch('https://governapi.com/api/security-scan-results')
      const data = await response.json()
      
      if (data.success && data.results) {
        const vulns = data.results.vulnerabilities || []
        const criticalCount = vulns.filter(v => v.severity === 'CRITICAL').length
        const highCount = vulns.filter(v => v.severity === 'HIGH').length
        const mediumCount = vulns.filter(v => v.severity === 'MEDIUM').length
        
        // Calculate health score (100 - vulnerability penalties)
        const healthScore = Math.max(0, 100 - (criticalCount * 30) - (highCount * 15) - (mediumCount * 5))
        
        setHealthData({
          overallHealth: healthScore,
          vulnerabilityCount: vulns.length,
          criticalIssues: criticalCount + highCount,
          riskLevel: data.results.overall_risk
        })
      }
    } catch (error) {
      console.error('Failed to fetch health data:', error)
    }
  }

  const getHealthColor = (score) => {
    if (score >= 80) return '#52c41a'
    if (score >= 60) return '#faad14'
    if (score >= 40) return '#fa8c16'
    return '#ff4d4f'
  }

  return (
    <Card title="API Health Overview">
      <Row gutter={16} align="middle">
        <Col span={12}>
          <div style={{ textAlign: 'center' }}>
            <Progress
              type="circle"
              percent={healthData.overallHealth}
              strokeColor={getHealthColor(healthData.overallHealth)}
              size={120}
              format={percent => `${percent}%`}
            />
            <div style={{ marginTop: 8, fontSize: '16px', fontWeight: 'bold' }}>
              Overall Health Score
            </div>
          </div>
        </Col>
        <Col span={12}>
          <Statistic
            title="Risk Level"
            value={healthData.riskLevel}
            valueStyle={{ color: getHealthColor(healthData.overallHealth) }}
          />
          <Statistic
            title="Total Vulnerabilities"
            value={healthData.vulnerabilityCount}
            valueStyle={{ color: healthData.vulnerabilityCount > 0 ? '#ff4d4f' : '#52c41a' }}
          />
          <Statistic
            title="Critical/High Issues"
            value={healthData.criticalIssues}
            valueStyle={{ color: healthData.criticalIssues > 0 ? '#ff4d4f' : '#52c41a' }}
          />
        </Col>
      </Row>
    </Card>
  )
}
