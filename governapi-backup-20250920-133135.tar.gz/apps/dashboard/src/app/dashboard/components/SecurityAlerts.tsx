'use client'

import { Card, List, Tag, Alert } from 'antd'
import { useState, useEffect } from 'react'

export function SecurityAlerts() {
  const [alerts, setAlerts] = useState([])

  useEffect(() => {
    fetchAlerts()
  }, [])

  const fetchAlerts = async () => {
    try {
      const response = await fetch('https://governapi.com/api/security-scan-results')
      const data = await response.json()
      
      if (data.success && data.results) {
        const criticalAlerts = data.results.vulnerabilities
          ?.filter(v => v.severity === 'CRITICAL' || v.severity === 'HIGH')
          ?.map(v => ({
            id: Math.random(),
            severity: v.severity,
            message: v.finding,
            timestamp: data.results.timestamp
          })) || []
        
        setAlerts(criticalAlerts)
      }
    } catch (error) {
      console.error('Failed to fetch alerts:', error)
    }
  }

  if (alerts.length === 0) {
    return (
      <Card title="Security Alerts">
        <Alert message="No recent security alerts. Run a security scan to generate alerts." type="info" />
      </Card>
    )
  }

  return (
    <Card title="Security Alerts">
      <List
        size="small"
        dataSource={alerts}
        renderItem={alert => (
          <List.Item>
            <Tag color={alert.severity === 'CRITICAL' ? 'red' : 'orange'}>
              {alert.severity}
            </Tag>
            <span>{alert.message}</span>
            <small style={{ color: '#666', marginLeft: 8 }}>
              {new Date(alert.timestamp).toLocaleString()}
            </small>
          </List.Item>
        )}
      />
    </Card>
  )
}
