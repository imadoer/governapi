'use client'

import { Card, Alert, List, Tag } from 'antd'
import { useState, useEffect } from 'react'

export function RiskAssessment() {
  const [riskData, setRiskData] = useState({
    overall_risk: 'UNKNOWN',
    vulnerabilities: [],
    recommendations: []
  })

  useEffect(() => {
    fetchRiskData()
  }, [])

  const fetchRiskData = async () => {
    try {
      const response = await fetch('https://governapi.com/api/security-scan-results')
      const data = await response.json()
      
      if (data.success && data.results) {
        setRiskData({
          overall_risk: data.results.overall_risk,
          vulnerabilities: data.results.vulnerabilities?.slice(0, 5) || [],
          recommendations: data.results.headers_analysis?.recommendations?.slice(0, 3) || []
        })
      }
    } catch (error) {
      console.error('Failed to fetch risk data:', error)
    }
  }

  const getRiskColor = (risk) => {
    const colors = {
      'LOW': 'success',
      'MEDIUM': 'warning', 
      'HIGH': 'error',
      'CRITICAL': 'error'
    }
    return colors[risk] || 'info'
  }

  if (riskData.vulnerabilities.length === 0) {
    return (
      <Card title="Risk Assessment">
        <Alert message="No security scan data available. Run a scan to assess risks." type="info" />
      </Card>
    )
  }

  return (
    <Card title="Risk Assessment">
      <Alert 
        message={`Overall Risk Level: ${riskData.overall_risk}`}
        type={getRiskColor(riskData.overall_risk)}
        style={{ marginBottom: 16 }}
      />
      
      <h4>Top Vulnerabilities:</h4>
      <List
        size="small"
        dataSource={riskData.vulnerabilities}
        renderItem={vuln => (
          <List.Item>
            <Tag color={vuln.severity === 'HIGH' ? 'red' : 'orange'}>
              {vuln.severity}
            </Tag>
            {vuln.finding}
          </List.Item>
        )}
      />
      
      {riskData.recommendations.length > 0 && (
        <>
          <h4 style={{ marginTop: 16 }}>Recommendations:</h4>
          <List
            size="small"
            dataSource={riskData.recommendations}
            renderItem={rec => <List.Item>{rec}</List.Item>}
          />
        </>
      )}
    </Card>
  )
}
