'use client'

import { Card, Row, Col, Statistic, Spin, Table } from 'antd'
import { useState, useEffect } from 'react'

export function TrendingDashboard() {
  const [trendData, setTrendData] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchTrendData()
  }, [])

  const fetchTrendData = async () => {
    try {
      const response = await fetch('https://governapi.com/api/trends')
      const data = await response.json()
      setTrendData(data)
    } catch (error) {
      console.error('Failed to fetch trend data:', error)
    }
    setLoading(false)
  }

  if (loading) {
    return <Card><Spin size="large" /></Card>
  }

  if (!trendData || trendData.trends.length === 0) {
    return (
      <Card title="Security Trends">
        <p>No historical data available. Run more security scans to see trends over time.</p>
      </Card>
    )
  }

  const { trends, summary } = trendData

  const columns = [
    {
      title: 'Date',
      dataIndex: 'timestamp',
      render: (timestamp) => new Date(timestamp).toLocaleDateString()
    },
    {
      title: 'Target',
      dataIndex: 'target',
      render: (target) => target.length > 40 ? target.substring(0, 40) + '...' : target
    },
    {
      title: 'Risk',
      dataIndex: 'overall_risk',
      render: (risk) => (
        <span style={{ 
          color: risk === 'CRITICAL' ? '#ff4d4f' : 
                 risk === 'HIGH' ? '#ff7a45' : 
                 risk === 'MEDIUM' ? '#faad14' : '#52c41a',
          fontWeight: 'bold'
        }}>
          {risk}
        </span>
      )
    },
    {
      title: 'Vulnerabilities',
      dataIndex: 'vulnerability_count'
    },
    {
      title: 'Critical',
      dataIndex: 'critical_count',
      render: (count) => <span style={{ color: count > 0 ? '#ff4d4f' : '#666' }}>{count}</span>
    },
    {
      title: 'High', 
      dataIndex: 'high_count',
      render: (count) => <span style={{ color: count > 0 ? '#ff7a45' : '#666' }}>{count}</span>
    }
  ]

  return (
    <div>
      <Row gutter={[16, 16]} style={{ marginBottom: 16 }}>
        <Col span={6}>
          <Statistic
            title="Total Scans"
            value={summary.total_scans}
          />
        </Col>
        <Col span={6}>
          <Statistic
            title="Avg Vulnerabilities"
            value={summary.avg_vulnerabilities}
            valueStyle={{ color: summary.avg_vulnerabilities > 5 ? '#ff4d4f' : '#52c41a' }}
          />
        </Col>
        <Col span={6}>
          <Statistic
            title="Risk Trend"
            value={summary.risk_trend.toUpperCase()}
            valueStyle={{ 
              color: summary.risk_trend === 'increasing' ? '#ff4d4f' : 
                     summary.risk_trend === 'decreasing' ? '#52c41a' : '#faad14' 
            }}
          />
        </Col>
        <Col span={6}>
          <Statistic
            title="Latest Risk"
            value={trends[trends.length - 1]?.overall_risk || 'Unknown'}
          />
        </Col>
      </Row>

      <Card title="Security Scan History">
        <Table 
          dataSource={trends}
          columns={columns}
          rowKey="timestamp"
          pagination={{ pageSize: 10 }}
        />
      </Card>
    </div>
  )
}
