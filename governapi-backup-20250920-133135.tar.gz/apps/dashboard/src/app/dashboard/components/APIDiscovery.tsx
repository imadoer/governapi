'use client'

import { Card, Form, Input, Select, Button, Table, Tag, Statistic, Row, Col, message } from 'antd'
import { useState, useEffect } from 'react'

export function APIDiscovery() {
  const [discoveredAPIs, setDiscoveredAPIs] = useState([])
  const [stats, setStats] = useState({})
  const [loading, setLoading] = useState(false)
  const [form] = Form.useForm()

  useEffect(() => {
    fetchDiscoveredAPIs()
  }, [])

  const fetchDiscoveredAPIs = async () => {
    try {
      const response = await fetch('https://governapi.com/api/discovery')
      const data = await response.json()
      setDiscoveredAPIs(data.apis || [])
      setStats(data.stats || {})
    } catch (error) {
      console.error('Failed to fetch discovered APIs:', error)
    }
  }

  const handleDiscovery = async (values) => {
    setLoading(true)
    try {
      console.log('Sending discovery request:', values)
      
      const response = await fetch('https://governapi.com/api/discovery', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(values)
      })
      
      console.log('Response status:', response.status)
      const result = await response.json()
      console.log('Response data:', result)
      
      if (result.success) {
        message.success(`Discovered ${result.discovered_count} API endpoints`)
        await fetchDiscoveredAPIs()
        form.resetFields()
      } else {
        message.error(`Discovery failed: ${result.error || 'Unknown error'}`)
      }
    } catch (error) {
      console.error('Discovery error:', error)
      message.error('Failed to perform API discovery: ' + error.message)
    } finally {
      setLoading(false)
    }
  }

  const scanSelectedAPI = async (apiUrl) => {
    try {
      const response = await fetch('https://governapi.com/api/security-scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ target_url: apiUrl })
      })
      
      if (response.ok) {
        message.success(`Security scan initiated for ${apiUrl}`)
      } else {
        message.error('Failed to start security scan')
      }
    } catch (error) {
      message.error('Error initiating scan')
    }
  }

  const columns = [
    { 
      title: 'URL', 
      dataIndex: 'url',
      render: (url) => (
        <a href={url} target="_blank" rel="noopener noreferrer">
          {url.length > 50 ? url.substring(0, 50) + '...' : url}
        </a>
      )
    },
    { 
      title: 'Type', 
      dataIndex: 'api_type',
      render: (type) => {
        const color = {
          'REST': 'blue',
          'GraphQL': 'purple',
          'SOAP': 'orange',
          'Unknown': 'gray'
        }[type]
        return <Tag color={color}>{type}</Tag>
      }
    },
    { 
      title: 'Status', 
      dataIndex: 'status_code',
      render: (status) => {
        const color = status < 300 ? 'green' : status < 400 ? 'orange' : 'red'
        return <Tag color={color}>{status}</Tag>
      }
    },
    { 
      title: 'Response Time', 
      dataIndex: 'response_time',
      render: (time) => `${time}ms`
    },
    {
      title: 'Auth Required',
      dataIndex: 'authentication_required',
      render: (required) => required ? <Tag color="red">Yes</Tag> : <Tag color="green">No</Tag>
    },
    {
      title: 'Actions',
      render: (_, record) => (
        <Button size="small" onClick={() => scanSelectedAPI(record.url)}>
          Scan
        </Button>
      )
    }
  ]

  return (
    <div>
      <Card title="API Discovery" style={{ marginBottom: 16 }}>
        <Form form={form} onFinish={handleDiscovery} layout="inline">
          <Form.Item
            name="target_domain"
            rules={[{ required: true, message: 'Domain is required' }]}
          >
            <Input placeholder="api.company.com or https://api.company.com" style={{ width: 300 }} />
          </Form.Item>
          
          <Form.Item name="scan_type" initialValue="both">
            <Select style={{ width: 150 }}>
              <Select.Option value="network">Network Scan</Select.Option>
              <Select.Option value="openapi">OpenAPI Spec</Select.Option>
              <Select.Option value="both">Both</Select.Option>
            </Select>
          </Form.Item>
          
          <Form.Item>
            <Button type="primary" htmlType="submit" loading={loading}>
              Discover APIs
            </Button>
          </Form.Item>
        </Form>
      </Card>

      <Row gutter={16} style={{ marginBottom: 16 }}>
        <Col span={6}>
          <Statistic title="Total APIs" value={stats.total_apis || 0} />
        </Col>
        <Col span={6}>
          <Statistic title="REST APIs" value={stats.by_type?.REST || 0} />
        </Col>
        <Col span={6}>
          <Statistic title="GraphQL APIs" value={stats.by_type?.GraphQL || 0} />
        </Col>
        <Col span={6}>
          <Statistic title="Success Rate" value={((stats.by_status?.success || 0) / (stats.total_apis || 1) * 100).toFixed(1)} suffix="%" />
        </Col>
      </Row>

      <Card title="Discovered APIs">
        <Table 
          dataSource={discoveredAPIs}
          columns={columns}
          pagination={{ pageSize: 10 }}
          size="small"
          rowKey="url"
        />
      </Card>
    </div>
  )
}
