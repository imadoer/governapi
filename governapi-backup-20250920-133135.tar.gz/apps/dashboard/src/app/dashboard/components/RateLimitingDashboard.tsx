'use client'

import { Card, Form, InputNumber, Switch, Button, message, Row, Col, Statistic, Table } from 'antd'
import { useState, useEffect } from 'react'

export function RateLimitingDashboard() {
  const [form] = Form.useForm()
  const [loading, setLoading] = useState(false)
  const [config, setConfig] = useState(null)
  const [stats, setStats] = useState(null)

  useEffect(() => {
    fetchConfig()
    const interval = setInterval(fetchConfig, 30000) // Refresh every 30 seconds
    return () => clearInterval(interval)
  }, [])

  const fetchConfig = async () => {
    try {
      const response = await fetch('https://governapi.com/api/rate-limit-config')
      const data = await response.json()
      setConfig(data.config)
      setStats(data.stats)
      form.setFieldsValue(data.config)
    } catch (error) {
      console.error('Failed to fetch rate limit config:', error)
    }
  }

  const handleSave = async (values) => {
    setLoading(true)
    try {
      const response = await fetch('https://governapi.com/api/rate-limit-config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ config: values })
      })
      
      if (response.ok) {
        message.success('Rate limiting configuration updated successfully')
        fetchConfig()
      } else {
        message.error('Failed to update configuration')
      }
    } catch (error) {
      message.error('Error updating configuration')
    }
    setLoading(false)
  }

  const testRateLimit = async () => {
    try {
      message.info('Testing rate limit...')
      // Make multiple rapid requests to test rate limiting
      const promises = Array.from({ length: 10 }, (_, i) =>
        fetch('https://governapi.com/api/test-endpoint', { method: 'POST' }).catch(() => ({ status: 429 }))
      )
      
      const results = await Promise.all(promises)
      const rateLimited = results.filter(r => r.status === 429).length
      
      if (rateLimited > 0) {
        message.success(`Rate limiting working! ${rateLimited} requests blocked`)
      } else {
        message.warning('Rate limiting may not be active or limit not reached')
      }
    } catch (error) {
      message.error('Test failed')
    }
  }

  return (
    <div>
      <Row gutter={[16, 16]} style={{ marginBottom: 16 }}>
        <Col span={8}>
          <Statistic
            title="Active Rate Limited Keys"
            value={stats?.totalActiveKeys || 0}
            valueStyle={{ color: stats?.totalActiveKeys > 0 ? '#faad14' : '#52c41a' }}
          />
        </Col>
        <Col span={8}>
          <Statistic
            title="Currently Blocked"
            value={stats?.blockedKeys || 0}
            valueStyle={{ color: stats?.blockedKeys > 0 ? '#ff4d4f' : '#52c41a' }}
          />
        </Col>
        <Col span={8}>
          <Statistic
            title="Requests Per Window"
            value={config?.maxRequests || 100}
          />
        </Col>
      </Row>

      <Row gutter={[16, 16]}>
        <Col span={16}>
          <Card title="Rate Limiting Configuration">
            <Form
              form={form}
              layout="vertical"
              onFinish={handleSave}
              initialValues={config}
            >
              <Row gutter={16}>
                <Col span={12}>
                  <Form.Item
                    label="Enable Rate Limiting"
                    name="enabled"
                    valuePropName="checked"
                  >
                    <Switch />
                  </Form.Item>
                  
                  <Form.Item
                    label="Max Requests Per Window"
                    name="maxRequests"
                    help="Number of requests allowed per time window"
                  >
                    <InputNumber min={1} max={1000} />
                  </Form.Item>
                  
                  <Form.Item
                    label="Time Window (ms)"
                    name="windowMs"
                    help="Duration of rate limiting window in milliseconds"
                  >
                    <InputNumber min={1000} max={3600000} step={1000} />
                  </Form.Item>
                </Col>
                
                <Col span={12}>
                  <Form.Item
                    label="Block Duration (ms)"
                    name="blockDuration"
                    help="How long to block after exceeding limit"
                  >
                    <InputNumber min={60000} max={7200000} step={60000} />
                  </Form.Item>
                  
                  <Form.Item
                    label="Alert Threshold (%)"
                    name="alertThreshold"
                    help="Trigger alerts when this percentage of limit is reached"
                  >
                    <InputNumber min={10} max={100} />
                  </Form.Item>
                </Col>
              </Row>
              
              <Form.Item>
                <Button type="primary" htmlType="submit" loading={loading} style={{ marginRight: 8 }}>
                  Save Configuration
                </Button>
                <Button onClick={testRateLimit}>
                  Test Rate Limiting
                </Button>
              </Form.Item>
            </Form>
          </Card>
        </Col>
        
        <Col span={8}>
          <Card title="Current Settings">
            {config && (
              <div>
                <p><strong>Status:</strong> {config.enabled ? '✅ Enabled' : '❌ Disabled'}</p>
                <p><strong>Limit:</strong> {config.maxRequests} requests</p>
                <p><strong>Window:</strong> {config.windowMs / 1000} seconds</p>
                <p><strong>Block Time:</strong> {config.blockDuration / 60000} minutes</p>
                <p><strong>Alert at:</strong> {config.alertThreshold}% of limit</p>
              </div>
            )}
            
            {stats && (
              <div style={{ marginTop: 16, padding: 12, backgroundColor: '#f5f5f5', borderRadius: 4 }}>
                <strong>Live Stats:</strong>
                <br />Active Keys: {stats.totalActiveKeys}
                <br />Blocked: {stats.blockedKeys}
              </div>
            )}
          </Card>
        </Col>
      </Row>
    </div>
  )
}
