'use client'

import { Card, Statistic, Row, Col, Button } from 'antd'
import { useState, useEffect } from 'react'
import { ReloadOutlined } from '@ant-design/icons'

export function TrendAnalysis() {
  const [trends, setTrends] = useState({
    apiHealth: 0,
    threatsBlocked: 0,
    complianceScore: 0
  })
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    fetchRealTrends()
  }, [])

  const fetchRealTrends = async () => {
    setLoading(true)
    try {
      console.log('Fetching trends data...')
      
      // Get real scan results
      const scanResponse = await fetch('https://governapi.com/api/security-scan-results')
      const scanData = await scanResponse.json()
      console.log('Scan data:', scanData)
      
      // Get real bot detection data  
      const botResponse = await fetch('https://governapi.com/api/bot-detection')
      const botData = await botResponse.json()
      console.log('Bot data:', botData)
      
      // Calculate real metrics
      let apiHealth = 0
      let complianceScore = 0
      
      if (scanData.success && scanData.results) {
        const vulnCount = scanData.results.vulnerabilities?.length || 0
        const criticalVulns = scanData.results.vulnerabilities?.filter(v => v.severity === 'CRITICAL').length || 0
        const highVulns = scanData.results.vulnerabilities?.filter(v => v.severity === 'HIGH').length || 0
        
        // Calculate health based on vulnerabilities (start at 100, subtract for issues)
        apiHealth = Math.max(0, 100 - (criticalVulns * 30) - (highVulns * 15) - ((vulnCount - criticalVulns - highVulns) * 5))
        
        // Calculate compliance based on scan findings
        const hasHttps = scanData.results.ssl_analysis?.certificate_valid !== false
        const securityHeaders = scanData.results.headers_analysis?.security_headers_present?.length || 0
        const totalPossibleHeaders = 6 // Total security headers we check for
        const missingHeaders = scanData.results.headers_analysis?.security_headers_missing?.length || 0
        
        complianceScore = Math.round(
          (hasHttps ? 40 : 0) + // 40% for HTTPS
          ((totalPossibleHeaders - missingHeaders) / totalPossibleHeaders * 60) // 60% for security headers
        )
        
        console.log('Calculated values:', { apiHealth, complianceScore, vulnCount, criticalVulns, highVulns })
      }
      
      setTrends({
        apiHealth: Math.round(apiHealth),
        threatsBlocked: botData.bots_blocked || 0,
        complianceScore: Math.round(complianceScore)
      })
    } catch (error) {
      console.error('Failed to fetch real trends:', error)
    }
    setLoading(false)
  }

  return (
    <Card 
      title="Security Trends (Real Data)" 
      extra={
        <Button 
          icon={<ReloadOutlined />} 
          onClick={fetchRealTrends}
          loading={loading}
          size="small"
        >
          Refresh
        </Button>
      }
    >
      <Row gutter={16}>
        <Col span={8}>
          <Statistic
            title="API Health"
            value={trends.apiHealth}
            suffix="%"
            valueStyle={{ color: trends.apiHealth > 70 ? '#52c41a' : trends.apiHealth > 40 ? '#faad14' : '#ff4d4f' }}
          />
        </Col>
        <Col span={8}>
          <Statistic
            title="Threats Blocked"
            value={trends.threatsBlocked}
            valueStyle={{ color: '#52c41a' }}
          />
        </Col>
        <Col span={8}>
          <Statistic
            title="Compliance Score"
            value={trends.complianceScore}
            suffix="%"
            valueStyle={{ color: trends.complianceScore > 70 ? '#52c41a' : '#faad14' }}
          />
        </Col>
      </Row>
      <div style={{ marginTop: 16, fontSize: '12px', color: '#666' }}>
        Based on latest security scan and bot detection data. Check browser console for debug info.
      </div>
    </Card>
  )
}
