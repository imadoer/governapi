'use client'

import { Card, Form, Input, Select, Button, Table, Switch, Tag, message } from 'antd'
import { useState, useEffect } from 'react'

export function WebhookIntegration() {
  const [webhooks, setWebhooks] = useState([])
  const [loading, setLoading] = useState(false)
  const [form] = Form.useForm()

  useEffect(() => {
    fetchWebhooks()
  }, [])

  const fetchWebhooks = async () => {
    try {
      const response = await fetch('https://governapi.com/api/webhooks')
      const data = await response.json()
      setWebhooks(data.webhooks || [])
    } catch (error) {
      console.error('Failed to fetch webhooks:', error)
    }
  }

  const handleCreateWebhook = async (values) => {
    setLoading(true)
    try {
      const response = await fetch('https://governapi.com/api/webhooks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(values)
      })
      
      if (response.ok) {
        message.success('Webhook created successfully')
        form.resetFields()
        fetchWebhooks()
      } else {
        message.error('Failed to create webhook')
      }
    } catch (error) {
      message.error('Error creating webhook')
    }
    setLoading(false)
  }

  const testWebhook = async (webhook) => {
    try {
      const response = await fetch('https://governapi.com/api/webhooks/trigger', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          event_type: 'security_scan',
          data: {
            target: 'test-api.example.com',
            vulnerability_count: 5,
            overall_risk: 'HIGH',
            severity: 'HIGH',
            timestamp: new Date().toISOString()
          }
        })
      })
      
      if (response.ok) {
        message.success('Test webhook sent successfully')
      } else {
        message.error('Failed to send test webhook')
      }
    } catch (error) {
      message.error('Error sending test webhook')
    }
  }

  const columns = [
    { title: 'Name', dataIndex: 'name' },
    { 
      title: 'Type', 
      dataIndex: 'type',
      render: (type) => <Tag color="blue">{type.toUpperCase()}</Tag>
    },
    { 
      title: 'URL', 
      dataIndex: 'url',
      render: (url) => url.substring(0, 50) + (url.length > 50 ? '...' : '')
    },
    { 
      title: 'Events', 
      dataIndex: 'events',
      render: (events) => events.map(event => <Tag key={event}>{event}</Tag>)
    },
    { 
      title: 'Status', 
      dataIndex: 'enabled',
      render: (enabled) => <Tag color={enabled ? 'green' : 'red'}>{enabled ? 'Active' : 'Disabled'}</Tag>
    },
    {
      title: 'Actions',
      render: (_, record) => (
        <Button size="small" onClick={() => testWebhook(record)}>
          Test
        </Button>
      )
    }
  ]

  return (
    <div>
      <Card title="Webhook Integration" style={{ marginBottom: 16 }}>
        <Form form={form} onFinish={handleCreateWebhook} layout="vertical">
          <Form.Item
            label="Webhook Name"
            name="name"
            rules={[{ required: true, message: 'Name is required' }]}
          >
            <Input placeholder="Security Alerts to Slack" />
          </Form.Item>
          
          <Form.Item
            label="Webhook URL"
            name="url"
            rules={[{ required: true, message: 'URL is required' }]}
          >
            <Input placeholder="https://hooks.slack.com/services/..." />
          </Form.Item>
          
          <Form.Item label="Type" name="type" initialValue="slack">
            <Select>
              <Select.Option value="slack">Slack</Select.Option>
              <Select.Option value="discord">Discord</Select.Option>
              <Select.Option value="teams">Microsoft Teams</Select.Option>
              <Select.Option value="generic">Generic Webhook</Select.Option>
            </Select>
          </Form.Item>
          
          <Form.Item label="Events" name="events" initialValue={['security_scan', 'vulnerability_found']}>
            <Select mode="multiple">
              <Select.Option value="security_scan">Security Scan Completed</Select.Option>
              <Select.Option value="vulnerability_found">Vulnerability Found</Select.Option>
              <Select.Option value="high_risk_detected">High Risk Detected</Select.Option>
              <Select.Option value="api_discovered">API Discovered</Select.Option>
            </Select>
          </Form.Item>
          
          <Form.Item>
            <Button type="primary" htmlType="submit" loading={loading}>
              Create Webhook
            </Button>
          </Form.Item>
        </Form>
      </Card>

      <Card title="Active Webhooks">
        <Table 
          dataSource={webhooks}
          columns={columns}
          pagination={false}
          size="small"
          rowKey="id"
        />
      </Card>
    </div>
  )
}
