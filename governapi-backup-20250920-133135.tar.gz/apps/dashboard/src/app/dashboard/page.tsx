'use client'

import { useState, useEffect } from 'react'
import { Layout, Menu, Tabs, Card, Row, Col, Button, Modal, Input, Form, message, Space, Typography, Spin } from 'antd'
import { 
  DashboardOutlined, 
  SecurityScanOutlined, 
  ApiOutlined, 
  SettingOutlined,
  FileTextOutlined,
  PlusOutlined,
  UserOutlined,
  LogoutOutlined
} from '@ant-design/icons'
import { signOut, useSession } from 'next-auth/react'
import { APIHealthScore } from './components/APIHealthScore'
import { LiveAPIMonitoring } from './components/LiveAPIMonitoring'
import { TrendAnalysis } from './components/TrendAnalysis'
import { RiskAssessment } from './components/RiskAssessment'
import { SecurityAlerts } from './components/SecurityAlerts'
import { PerformanceMetrics } from './components/PerformanceMetrics'
import { SecurityScanResults } from './components/SecurityScanResults'
import { APIDiscovery } from './components/APIDiscovery'
import { BotDetection } from './components/BotDetection'
import { RealComplianceDashboard } from './components/RealComplianceDashboard'
import { IntegrationStatus } from './components/IntegrationStatus'
import { PDFReportGenerator } from './components/PDFReportGenerator'
import { DependencyMap } from './components/DependencyMap'
import { WebhookIntegration } from './components/WebhookIntegration'
import { UserManagement } from './components/UserManagement'
import { ScheduledScanning } from './components/ScheduledScanning'
import { TrendingDashboard } from './components/TrendingDashboard'
import { AlertThresholds } from './components/AlertThresholds'
import { RateLimitingDashboard } from './components/RateLimitingDashboard'
import { ThreatMonitoring } from './components/ThreatMonitoring'

const { Sider, Header, Content } = Layout
const { Title } = Typography
const { TextArea } = Input

export default function DashboardPage() {
  const { data: session } = useSession()
  const [activeTab, setActiveTab] = useState('overview')
  const [collapsed, setCollapsed] = useState(false)
  const [scanModalVisible, setScanModalVisible] = useState(false)
  const [addAPIModalVisible, setAddAPIModalVisible] = useState(false)
  const [loading, setLoading] = useState(false)
  const [scanResults, setScanResults] = useState(null)
  const [form] = Form.useForm()
  const [apiForm] = Form.useForm()

  const handleSecurityScan = async (values) => {
    setLoading(true)
    try {
      const response = await fetch('/api/security-scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(values)
      })
      
      if (response.ok) {
        const data = await response.json()
        setScanResults(data.results)
        message.success('Security scan completed successfully')
        setScanModalVisible(false)
        form.resetFields()
      } else {
        message.error('Security scan failed')
      }
    } catch (error) {
      message.error('Error performing security scan')
    }
    setLoading(false)
  }

  const handleAddAPI = async (values) => {
    try {
      message.success('API added successfully')
      setAddAPIModalVisible(false)
      apiForm.resetFields()
    } catch (error) {
      message.error('Error adding API')
    }
  }

  const handleGenerateReport = async (type) => {
    try {
      message.success(`${type} report generated successfully`)
    } catch (error) {
      message.error('Error generating report')
    }
  }

  const handleLogout = async () => {
    await signOut({ callbackUrl: '/login' })
  }

  const tabItems = [
    {
      key: 'overview',
      label: 'Overview',
      children: (
        <Row gutter={[16, 16]}>
          <Col xs={24} lg={12}>
            <Card title="Quick Actions">
              <Space wrap>
                <Button type="primary" icon={<PlusOutlined />} onClick={() => setScanModalVisible(true)}>
                  New Security Scan
                </Button>
                <Button icon={<ApiOutlined />} onClick={() => setAddAPIModalVisible(true)}>
                  Add API
                </Button>
                <Button icon={<FileTextOutlined />} onClick={() => handleGenerateReport("compliance")}>
                  Generate Report
                </Button>
              </Space>
            </Card>
          </Col>
          <Col xs={24} lg={12}>
            <Card title="System Status">
              <p>Your API governance platform is operational.</p>
              <p>All systems running normally.</p>
            </Card>
          </Col>
          <Col xs={24}>
            <APIHealthScore />
          </Col>
          <Col xs={24}>
            <LiveAPIMonitoring />
          </Col>
          <Col xs={24} lg={12}>
            <TrendAnalysis />
          </Col>
          <Col xs={24} lg={12}>
            <RiskAssessment />
          </Col>
          <Col xs={24} lg={12}>
            <SecurityAlerts />
          </Col>
          <Col xs={24} lg={12}>
            <PerformanceMetrics />
          </Col>
        </Row>
      )
    },
    {
      key: 'security',
      label: 'Security Scans',
      children: (
        <div>
          <Card title="Security Scans" extra={
            <Button type="primary" icon={<PlusOutlined />} onClick={() => setScanModalVisible(true)}>
              New Security Scan
            </Button>
          }>
            <p>Security scanning functionality active.</p>
          </Card>
          <SecurityScanResults results={scanResults} />
          <div style={{ marginTop: 16 }}>
            <ScheduledScanning />
          </div>
        </div>
      )
    },
    {
      key: 'threats',
      label: 'Threat Monitoring',
      children: <ThreatMonitoring />
    },
    {
      key: 'discovery',
      label: 'API Discovery',
      children: <APIDiscovery />
    },
    {
      key: 'alerts',
      label: 'Alert Configuration',
      children: <AlertThresholds />
    },
    {
      key: 'bots',
      label: 'Bot Detection',
      children: <BotDetection />
    },
    {
      key: 'reports',
      label: 'Compliance Reports',
      children: <RealComplianceDashboard />
    },
    {
      key: 'trends',
      label: 'Security Trends',
      children: <TrendingDashboard />
    },
    {
      key: 'ratelimit',
      label: 'Rate Limiting',
      children: <RateLimitingDashboard />
    },
    {
      key: 'enterprise',
      label: 'Enterprise',
      children: (
        <Row gutter={[16, 16]}>
          <Col xs={24} lg={12}>
            <IntegrationStatus />
          </Col>
          <Col xs={24} lg={12}>
            <PDFReportGenerator />
          </Col>
          <Col xs={24}>
            <WebhookIntegration />
          </Col>
          <Col xs={24}>
            <DependencyMap />
          </Col>
          <Col xs={24}>
            <UserManagement />
          </Col>
        </Row>
      )
    }
  ]

  return (
    <Layout style={{ minHeight: '100vh' }}>
      <Sider
        collapsible
        collapsed={collapsed}
        onCollapse={setCollapsed}
        theme="dark"
        width={250}
      >
        <div style={{ 
          color: 'white', 
          padding: '16px', 
          fontSize: '18px', 
          fontWeight: 'bold',
          textAlign: collapsed ? 'center' : 'left'
        }}>
          {collapsed ? 'GA' : 'GovernAPI'}
        </div>
        <Menu
          theme="dark"
          selectedKeys={[activeTab]}
          mode="inline"
          items={[
            { key: "overview", icon: <DashboardOutlined />, label: "Overview" },
            { key: "security", icon: <SecurityScanOutlined />, label: "Security Scans" },
            { key: "threats", icon: <SettingOutlined />, label: "Threat Monitoring" },
            { key: "discovery", icon: <ApiOutlined />, label: "API Discovery" },
            { key: "alerts", icon: <SettingOutlined />, label: "Alert Configuration" },
            { key: "bots", icon: <SecurityScanOutlined />, label: "Bot Detection" },
            { key: "reports", icon: <FileTextOutlined />, label: "Compliance Reports" },
            { key: "trends", icon: <DashboardOutlined />, label: "Security Trends" },
            { key: "ratelimit", icon: <SettingOutlined />, label: "Rate Limiting" },
            { key: "enterprise", icon: <ApiOutlined />, label: "Enterprise" }
          ]}
          onClick={({ key }) => setActiveTab(key)}
        />
      </Sider>
      
      <Layout>
        <Header style={{ 
          background: 'white', 
          padding: '0 24px', 
          display: 'flex', 
          justifyContent: 'space-between', 
          alignItems: 'center',
          borderBottom: '1px solid #f0f0f0'
        }}>
          <Title level={4} style={{ margin: 0 }}>
            API Governance Dashboard
          </Title>
          <Space>
            <Button 
              type="text" 
              icon={<UserOutlined />}
            >
              {session?.user?.email || 'User'}
            </Button>
            <Button 
              type="text" 
              icon={<LogoutOutlined />} 
              onClick={handleLogout}
            >
              Logout
            </Button>
          </Space>
        </Header>
        
        <Content style={{ margin: '24px' }}>
          <Tabs
            activeKey={activeTab}
            onChange={setActiveTab}
            items={tabItems}
          />
        </Content>
      </Layout>

      <Modal
        title="New Security Scan"
        open={scanModalVisible}
        onCancel={() => setScanModalVisible(false)}
        footer={null}
      >
        <Form form={form} onFinish={handleSecurityScan} layout="vertical">
          <Form.Item
            name="target_url"
            label="Target URL"
            rules={[
              { required: true, message: 'Please enter target URL' },
              { type: 'url', message: 'Please enter a valid URL' }
            ]}
          >
            <Input placeholder="https://example.com/api" />
          </Form.Item>
          <Form.Item>
            <Button type="primary" htmlType="submit" loading={loading}>
              Start Security Scan
            </Button>
          </Form.Item>
        </Form>
      </Modal>

      <Modal
        title="Add API"
        open={addAPIModalVisible}
        onCancel={() => setAddAPIModalVisible(false)}
        footer={null}
      >
        <Form form={apiForm} onFinish={handleAddAPI} layout="vertical">
          <Form.Item
            name="api_name"
            label="API Name"
            rules={[{ required: true, message: 'Please enter API name' }]}
          >
            <Input placeholder="My API" />
          </Form.Item>
          <Form.Item
            name="api_url"
            label="API URL"
            rules={[
              { required: true, message: 'Please enter API URL' },
              { type: 'url', message: 'Please enter a valid URL' }
            ]}
          >
            <Input placeholder="https://api.example.com" />
          </Form.Item>
          <Form.Item
            name="description"
            label="Description"
          >
            <TextArea placeholder="API description..." />
          </Form.Item>
          <Form.Item>
            <Button type="primary" htmlType="submit">
              Add API
            </Button>
          </Form.Item>
        </Form>
      </Modal>
    </Layout>
  )
}
