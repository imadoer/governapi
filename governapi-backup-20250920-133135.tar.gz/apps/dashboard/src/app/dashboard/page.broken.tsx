'use client'
import { useState, useEffect } from 'react'
import { Button, Card, Table, Tag, Space, Row, Col, Statistic, Layout, Menu, Modal, Form, Input, message, Avatar, Dropdown, Progress, Alert, Select, DatePicker, Badge, Typography, Divider, Tabs, Timeline, Tooltip } from 'antd'
  DashboardOutlined, ClockCircleOutlined, ExclamationCircleOutlined,
  FilterOutlined, DownloadOutlined, ReloadOutlined, ApiOutlined,
  BellOutlined, QuestionCircleOutlined, SearchOutlined, MenuFoldOutlined,
  MenuUnfoldOutlined, ProjectOutlined, FileTextOutlined, TeamOutlined,
  GlobalOutlined, DollarOutlined, LineChartOutlined, SafetyCertificateOutlined,
  AuditOutlined, RiseOutlined, FallOutlined
} from '@ant-design/icons'
import { useRouter } from 'next/navigation'

const { Header, Content, Sider } = Layout
const { Title, Text } = Typography
const { RangePicker } = DatePicker
const { TabPane } = Tabs

export default function DashboardPage() {
  const router = useRouter()
  const [collapsed, setCollapsed] = useState(false)
  const [scanModalVisible, setScanModalVisible] = useState(false)

  // Governance Overview Data
  const apiInventory = {
    total: 342,
    discovered: 28,
    classified: 314,
    unclassified: 28,
    critical: 45,
    internal: 186,
    external: 156
  }

  const policyViolations = [
    { id: 'POL-001', api: 'payment-api', policy: 'Data Encryption', severity: 'critical', age: '2 hours' },
    { id: 'POL-002', api: 'user-service', policy: 'Rate Limiting', severity: 'high', age: '1 day' },
    { id: 'POL-003', api: 'analytics-api', policy: 'Authentication Required', severity: 'high', age: '3 days' },
    { id: 'POL-004', api: 'legacy-api', policy: 'Deprecated Version', severity: 'medium', age: '1 week' },
  ]

  const costAnalytics = {
    totalMonthly: 45678,
    legitimate: 32456,
    suspicious: 8934,
    blocked: 4288,
    savings: 13222,
    savingsPercent: 28.9
  }

  const complianceScores = [
    { framework: 'SOC2', score: 92, trend: 'up', change: 3 },
    { framework: 'GDPR', score: 88, trend: 'up', change: 5 },
    { framework: 'PCI-DSS', score: 79, trend: 'down', change: -2 },
    { framework: 'HIPAA', score: 94, trend: 'stable', change: 0 },
  ]

  const recentActivity = [
    { time: '10:23 AM', event: 'New API discovered: order-service-v2', type: 'discovery' },
    { time: '09:45 AM', event: 'Critical vulnerability patched in payment-api', type: 'security' },
    { time: '09:12 AM', event: 'Policy violation: Rate limit exceeded on user-api', type: 'policy' },
    { time: '08:30 AM', event: 'Compliance report generated for SOC2', type: 'compliance' },
  ]

  const sideMenuItems = [
    { key: 'overview', icon: <DashboardOutlined />, label: 'Overview' },
    { key: 'inventory', icon: <ApiOutlined />, label: 'API Inventory' },
    { key: 'security', icon: <SecurityScanOutlined />, label: 'Security' },
    { key: 'policies', icon: <ProjectOutlined />, label: 'Policies' },
    { key: 'compliance', icon: <SafetyCertificateOutlined />, label: 'Compliance' },
    { key: 'costs', icon: <DollarOutlined />, label: 'Cost Analytics' },
    { key: 'reports', icon: <FileTextOutlined />, label: 'Reports' },
    { key: 'settings', icon: <SettingOutlined />, label: 'Settings' }
  ]

  const userMenuItems = [
    { key: 'profile', icon: <UserOutlined />, label: 'Profile' },
    { key: 'settings', icon: <SettingOutlined />, label: 'Settings' },
    { type: 'divider' },
    { key: 'logout', icon: <LogoutOutlined />, label: 'Sign Out', danger: true },
  ]

  return (
    <Layout className="min-h-screen">
      <Sider 
        trigger={null} 
        collapsible 
        collapsed={collapsed}
        className="bg-gray-900"
        width={240}
      >
        <div className="h-16 flex items-center justify-center text-white">
          {collapsed ? <h1 className="text-xl font-bold">G</h1> : <h1 className="text-xl font-bold">GovernAPI</h1>}
        </div>
        <Menu
          theme="dark"
          mode="inline"
          defaultSelectedKeys={['overview']}
          items={sideMenuItems}
          className="bg-gray-900 border-r-0"
        />
      </Sider>
      
      <Layout>
        <Header className="bg-white px-6 flex items-center justify-between shadow-sm">
          <div className="flex items-center">
            <Button
              type="text"
              icon={collapsed ? <MenuUnfoldOutlined /> : <MenuFoldOutlined />}
              onClick={() => setCollapsed(!collapsed)}
              className="text-lg"
            />
            <Input
              placeholder="Search APIs, policies, compliance..."
              prefix={<SearchOutlined />}
              className="ml-4 w-96"
              allowClear
            />
          </div>
          <Space size="large">
            <Badge count={policyViolations.filter(v => v.severity === 'critical').length} offset={[10, 0]}>
              <Button type="text" icon={<BellOutlined />} className="text-lg" />
            </Badge>
            <Button type="text" icon={<QuestionCircleOutlined />} className="text-lg" />
            <Dropdown menu={{ items: userMenuItems }} placement="bottomRight">
              <Space className="cursor-pointer">
                <Avatar className="bg-blue-600">JD</Avatar>
                <Text>John Doe</Text>
              </Space>
            </Dropdown>
          </Space>
        </Header>

        <Content className="p-6 bg-gray-50">
          {/* Page Header */}
          <div className="mb-6">
            <Title level={2} className="mb-2">API Governance Dashboard</Title>
            <Text type="secondary">Real-time overview of your API ecosystem health and compliance</Text>
          </div>

          {/* Critical Alerts */}
          {policyViolations.filter(v => v.severity === 'critical').length > 0 && (
            <Alert
              message="Critical Policy Violations"
              description={`${policyViolations.filter(v => v.severity === 'critical').length} critical violations require immediate attention. Data encryption policy violated in payment-api.`}
              type="error"
              showIcon
              icon={<ExclamationCircleOutlined />}
              action={
                <Button size="small" danger>
                  Review Now
                </Button>
              }
              className="mb-6"
              closable
            />
          )}

          {/* Key Metrics Row */}
          <Row gutter={[16, 16]} className="mb-6">
            <Col xs={24} sm={12} lg={6}>
              <Card>
                <Statistic
                  title="Total APIs"
                  value={apiInventory.total}
                  prefix={<ApiOutlined />}
                />
                <div className="mt-2">
                  <Text type="success">+{apiInventory.discovered} discovered this week</Text>
                </div>
              </Card>
            </Col>
            <Col xs={24} sm={12} lg={6}>
              <Card>
                <Statistic
                  title="Policy Compliance"
                  value={87}
                  suffix="%"
                  prefix={<SafetyCertificateOutlined />}
                  valueStyle={{ color: '#52c41a' }}
                />
                <Progress percent={87} showInfo={false} strokeColor="#52c41a" className="mt-2" />
              </Card>
            </Col>
            <Col xs={24} sm={12} lg={6}>
              <Card>
                <Statistic
                  title="Security Score"
                  value={92}
                  suffix="/100"
                  prefix={<SecurityScanOutlined />}
                  valueStyle={{ color: '#1890ff' }}
                />
                <Progress percent={92} showInfo={false} strokeColor="#1890ff" className="mt-2" />
              </Card>
            </Col>
            <Col xs={24} sm={12} lg={6}>
              <Card>
                <Statistic
                  title="Monthly Savings"
                  value={costAnalytics.savings}
                  prefix="$"
                  valueStyle={{ color: '#52c41a' }}
                />
                <div className="mt-2">
                  <Text type="success">{costAnalytics.savingsPercent}% cost reduction</Text>
                </div>
              </Card>
            </Col>
          </Row>

          {/* Main Content Tabs */}
          <Tabs defaultActiveKey="overview" type="card">
            <TabPane tab="Overview" key="overview">
              <Row gutter={[16, 16]}>
                {/* API Inventory Summary */}
                <Col xs={24} lg={12}>
                  <Card title="API Inventory" extra={<a>View All</a>}>
                    <Row gutter={[16, 16]}>
                      <Col span={12}>
                        <div className="text-center">
                          <Progress
                            type="circle"
                            percent={Math.round((apiInventory.classified / apiInventory.total) * 100)}
                            width={120}
                          />
                          <div className="mt-2">
                            <Text>Classification Status</Text>
                          </div>
                        </div>
                      </Col>
                      <Col span={12}>
                        <div className="space-y-3">
                          <div className="flex justify-between">
                            <Text>Critical APIs:</Text>
                            <Text strong>{apiInventory.critical}</Text>
                          </div>
                          <div className="flex justify-between">
                            <Text>Internal APIs:</Text>
                            <Text strong>{apiInventory.internal}</Text>
                          </div>
                          <div className="flex justify-between">
                            <Text>External APIs:</Text>
                            <Text strong>{apiInventory.external}</Text>
                          </div>
                          <div className="flex justify-between">
                            <Text>Unclassified:</Text>
                            <Text strong type="warning">{apiInventory.unclassified}</Text>
                          </div>
                        </div>
                      </Col>
                    </Row>
                  </Card>
                </Col>

                {/* Compliance Status */}
                <Col xs={24} lg={12}>
                  <Card title="Compliance Status" extra={<a>Configure</a>}>
                    <div className="space-y-4">
                      {complianceScores.map((framework, index) => (
                        <div key={index}>
                          <div className="flex justify-between items-center mb-1">
                            <Text strong>{framework.framework}</Text>
                            <Space>
                              <Text type={framework.trend === 'up' ? 'success' : framework.trend === 'down' ? 'danger' : 'secondary'}>
                                {framework.trend === 'up' ? <RiseOutlined /> : framework.trend === 'down' ? <FallOutlined /> : '-'}
                                {Math.abs(framework.change)}%
                              </Text>
                              <Text strong>{framework.score}%</Text>
                            </Space>
                          </div>
                          <Progress 
                            percent={framework.score} 
                            strokeColor={framework.score >= 80 ? '#52c41a' : '#faad14'}
                            showInfo={false}
                          />
                        </div>
                      ))}
                    </div>
                  </Card>
                </Col>

                {/* Policy Violations */}
                <Col xs={24}>
                  <Card 
                    title="Active Policy Violations" 
                    extra={
                      <Space>
                        <Badge count={policyViolations.length} showZero />
                        <Button size="small">View All</Button>
                      </Space>
                    }
                  >
                    <Table
                      dataSource={policyViolations}
                      pagination={false}
                      size="small"
                      columns={[
                        { title: 'ID', dataIndex: 'id', key: 'id', width: 100 },
                        { title: 'API', dataIndex: 'api', key: 'api' },
                        { title: 'Policy', dataIndex: 'policy', key: 'policy' },
                        { 
                          title: 'Severity', 
                          dataIndex: 'severity', 
                          key: 'severity',
                          render: (severity: string) => (
                            <Tag color={
                              severity === 'critical' ? 'error' : 
                              severity === 'high' ? 'warning' : 
                              'default'
                            }>
                              {severity.toUpperCase()}
                            </Tag>
                          )
                        },
                        { title: 'Age', dataIndex: 'age', key: 'age' },
                        {
                          title: 'Action',
                          key: 'action',
                          render: () => (
                            <Space>
                              <a>Review</a>
                              <a>Exempt</a>
                            </Space>
                          )
                        }
                      ]}
                    />
                  </Card>
                </Col>

                {/* Cost Analytics */}
                <Col xs={24} lg={12}>
                  <Card title="API Cost Analytics" extra={<Text type="secondary">This Month</Text>}>
                    <Row gutter={[16, 16]}>
                      <Col span={12}>
                        <Statistic 
                          title="Total API Costs" 
                          value={costAnalytics.totalMonthly} 
                          prefix="$"
                        />
                      </Col>
                      <Col span={12}>
                        <Statistic 
                          title="Cost Savings" 
                          value={costAnalytics.savings} 
                          prefix="$"
                          valueStyle={{ color: '#52c41a' }}
                        />
                      </Col>
                    </Row>
                    <Divider />
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <Text>Legitimate Traffic:</Text>
                        <Text>${costAnalytics.legitimate.toLocaleString()}</Text>
                      </div>
                      <div className="flex justify-between">
                        <Text>Suspicious Traffic:</Text>
                        <Text type="warning">${costAnalytics.suspicious.toLocaleString()}</Text>
                      </div>
                      <div className="flex justify-between">
                        <Text>Blocked Threats:</Text>
                        <Text type="danger">${costAnalytics.blocked.toLocaleString()}</Text>
                      </div>
                    </div>
                  </Card>
                </Col>

                {/* Recent Activity */}
                <Col xs={24} lg={12}>
                  <Card title="Recent Activity" extra={<a>View All</a>}>
                    <Timeline>
                      {recentActivity.map((activity, index) => (
                        <Timeline.Item 
                          key={index}
                          color={
                            activity.type === 'security' ? 'red' :
                            activity.type === 'discovery' ? 'blue' :
                            activity.type === 'policy' ? 'orange' :
                            'green'
                          }
                        >
                          <div>
                            <Text type="secondary">{activity.time}</Text>
                            <br />
                            <Text>{activity.event}</Text>
                          </div>
                        </Timeline.Item>
                      ))}
                    </Timeline>
                  </Card>
                </Col>
              </Row>
            </TabPane>

            <TabPane tab="Security Scans" key="security">
              <Card>
                <div className="text-center py-8">
                  <SecurityScanOutlined style={{ fontSize: '48px', color: '#8c8c8c' }} />
                  <Title level={4} className="mt-4">Security scan results will appear here</Title>
                  <Text type="secondary">Run your first security scan to see vulnerabilities</Text>
                  <div className="mt-4">
                    <Button type="primary" icon={<PlusOutlined />} onClick={() => setScanModalVisible(true)}>
                      New Security Scan
                    </Button>
                  </div>
                </div>
              </Card>
            </TabPane>

            <TabPane tab="Policy Engine" key="policies">
              <Card>
                <div className="text-center py-8">
                  <ProjectOutlined style={{ fontSize: '48px', color: '#8c8c8c' }} />
                  <Title level={4} className="mt-4">Policy configuration and violations</Title>
                  <Text type="secondary">Define and enforce governance policies</Text>
                  <div className="mt-4">
                    <Button type="primary" icon={<PlusOutlined />} onClick={() => setScanModalVisible(true)}>
                      Create Policy
                    </Button>
                  </div>
                </div>
              </Card>
            </TabPane>

            <TabPane tab="Compliance" key="compliance">
              <Card>
                <div className="text-center py-8">
                  <SafetyCertificateOutlined style={{ fontSize: '48px', color: '#8c8c8c' }} />
                  <Title level={4} className="mt-4">Compliance reports and audit trails</Title>
                  <Text type="secondary">Generate compliance reports for auditors</Text>
                  <div className="mt-4">
                    <Button type="primary" icon={<DownloadOutlined />}>
                      Generate Report
                    </Button>
                  </div>
                </div>
              </Card>
            </TabPane>
          </Tabs>
        </Content>
      </Layout>
      {/* Scan Modal */}
      <Modal
        title="Configure New Scan"
        open={scanModalVisible}
        onCancel={() => setScanModalVisible(false)}
        footer={null}
        width={600}
      >
        <Form
          layout="vertical"
          onFinish={async (values) => {
            try {
              const response = await fetch('/api/scanner', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(values)
              });
              const data = await response.json();
              if (data.success) {
                message.success('Scan started successfully!');
                setScanModalVisible(false);
              } else {
                message.error('Failed to start scan');
              }
            } catch (error) {
              message.error('Error starting scan');
            }
          }}
        >
          <Form.Item name="target" label="API Endpoint" rules={[{ required: true }]}>
            <Input placeholder="https://api.example.com" />
          </Form.Item>
          <Row gutter={16}>
            <Col span={12}>
              <Form.Item name="scanType" label="Scan Type" rules={[{ required: true }]}>
                <Select>
                  <Select.Option value="discovery">API Discovery</Select.Option>
                  <Select.Option value="security">Security Scan</Select.Option>
                  <Select.Option value="compliance">Compliance Check</Select.Option>
                  <Select.Option value="full">Full Audit</Select.Option>
                </Select>
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item name="environment" label="Environment" rules={[{ required: true }]}>
                <Select>
                  <Select.Option value="production">Production</Select.Option>
                  <Select.Option value="staging">Staging</Select.Option>
                  <Select.Option value="development">Development</Select.Option>
                </Select>
              </Form.Item>
            </Col>
          </Row>
          <Form.Item>
            <Button type="primary" htmlType="submit" block>
              Start Scan
            </Button>
          </Form.Item>
        </Form>
      </Modal>
    </Layout>
  )
}

      {/* Scan Modal */}
      <Modal
        title="Configure New Scan"
        open={scanModalVisible}
        onCancel={() => setScanModalVisible(false)}
        footer={null}
        width={600}
      >
        <Form
          layout="vertical"
          onFinish={async (values) => {
            try {
              const response = await fetch('/api/scanner', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(values)
              })
              const data = await response.json()
              if (data.success) {
                message.success('Scan started successfully!')
                setScanModalVisible(false)
                // Refresh scan list
              } else {
                message.error('Failed to start scan')
              }
            } catch (error) {
              message.error('Error starting scan')
            }
          }}
        >
          <Form.Item name="target" label="API Endpoint" rules={[{ required: true }]}>
            <Input placeholder="https://api.example.com" />
          </Form.Item>
          <Row gutter={16}>
            <Col span={12}>
              <Form.Item name="scanType" label="Scan Type" rules={[{ required: true }]}>
                <Select>
                  <Select.Option value="discovery">API Discovery</Select.Option>
                  <Select.Option value="security">Security Scan</Select.Option>
                  <Select.Option value="compliance">Compliance Check</Select.Option>
                  <Select.Option value="full">Full Audit</Select.Option>
                </Select>
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item name="environment" label="Environment" rules={[{ required: true }]}>
                <Select>
                  <Select.Option value="production">Production</Select.Option>
                  <Select.Option value="staging">Staging</Select.Option>
                  <Select.Option value="development">Development</Select.Option>
                </Select>
              </Form.Item>
            </Col>
          </Row>
          <Form.Item>
            <Button type="primary" htmlType="submit" block>
              Start Scan
            </Button>
          </Form.Item>
        </Form>
      </Modal>
