'use client'

import { useRouter } from 'next/navigation'
import { Button, Layout, Typography } from 'antd'
import { ArrowLeftOutlined } from '@ant-design/icons'

const { Header, Content } = Layout
const { Title, Paragraph } = Typography

export default function TermsOfService() {
  const router = useRouter()

  return (
    <Layout className="min-h-screen bg-white">
      <Header className="bg-slate-900 px-8">
        <div className="max-w-4xl mx-auto flex items-center justify-between h-full">
          <Button 
            type="text" 
            icon={<ArrowLeftOutlined />} 
            onClick={() => router.push('/')}
            className="text-white hover:text-blue-400"
          >
            Back to Home
          </Button>
        </div>
      </Header>

      <Content className="max-w-4xl mx-auto px-8 py-12">
        <Title level={1} className="mb-8">Terms of Service</Title>
        <Paragraph className="text-sm text-gray-500 mb-8">
          Last updated: September 13, 2025
        </Paragraph>

        <div className="space-y-8">
          <section>
            <Title level={2}>Acceptance of Terms</Title>
            <Paragraph>
              By accessing or using GovernAPI's services, you agree to be bound by these Terms of Service. 
              If you do not agree to these terms, do not use our services.
            </Paragraph>
          </section>

          <section>
            <Title level={2}>Service Description</Title>
            <Paragraph>
              GovernAPI provides API security, governance, and compliance monitoring services. 
              Our platform discovers, secures, and governs APIs across your organization while 
              automating compliance reporting and threat protection.
            </Paragraph>
          </section>

          <section>
            <Title level={2}>Account Responsibilities</Title>
            <Title level={3}>Account Security</Title>
            <Paragraph>
              You are responsible for maintaining the security of your account credentials and 
              all activities that occur under your account. Notify us immediately of any unauthorized access.
            </Paragraph>

            <Title level={3}>Accurate Information</Title>
            <Paragraph>
              You must provide accurate, current, and complete information when creating your account 
              and keep this information updated.
            </Paragraph>

            <Title level={3}>Compliance</Title>
            <Paragraph>
              You agree to use our services in compliance with all applicable laws, regulations, 
              and industry standards.
            </Paragraph>
          </section>

          <section>
            <Title level={2}>Acceptable Use Policy</Title>
            <Paragraph>You agree not to:</Paragraph>
            <ul className="list-disc pl-6 space-y-2">
              <li>Use our services for any unlawful purpose or in violation of any regulations</li>
              <li>Attempt to gain unauthorized access to our systems or other users' data</li>
              <li>Interfere with or disrupt our services or servers</li>
              <li>Use our services to monitor APIs you do not own or have permission to monitor</li>
              <li>Reverse engineer, decompile, or attempt to extract source code from our platform</li>
              <li>Share your account credentials with unauthorized parties</li>
            </ul>
          </section>

          <section>
            <Title level={2}>Service Level Agreement</Title>
            <Title level={3}>Uptime Commitment</Title>
            <Paragraph>
              We provide 99.9% uptime guarantee for our platform. Service credits may be available 
              for qualifying outages exceeding our SLA commitments.
            </Paragraph>

            <Title level={3}>Support</Title>
            <Paragraph>
              Support is provided according to your subscription plan:
            </Paragraph>
            <ul className="list-disc pl-6 space-y-2">
              <li>Starter Plan: 8x5 email support</li>
              <li>Professional Plan: 12x5 email and chat support</li>
              <li>Enterprise Plan: 24x7 phone, email, and dedicated support</li>
            </ul>
          </section>

          <section>
            <Title level={2}>Data and Privacy</Title>
            <Paragraph>
              Your data privacy and security are paramount. We process your data according to our 
              Privacy Policy and applicable data protection laws including GDPR, CCPA, and HIPAA where applicable.
            </Paragraph>
          </section>

          <section>
            <Title level={2}>Billing and Payment</Title>
            <Title level={3}>Subscription Fees</Title>
            <Paragraph>
              Subscription fees are billed monthly or annually based on your chosen plan. 
              All fees are non-refundable except where required by law.
            </Paragraph>

            <Title level={3}>Auto-Renewal</Title>
            <Paragraph>
              Subscriptions automatically renew unless cancelled at least 30 days before renewal. 
              You may cancel through your account settings or by contacting support.
            </Paragraph>

            <Title level={3}>Price Changes</Title>
            <Paragraph>
              We may change subscription prices with 30 days written notice. Existing customers 
              will be grandfathered at current rates for 12 months.
            </Paragraph>
          </section>

          <section>
            <Title level={2}>Limitation of Liability</Title>
            <Paragraph>
              To the maximum extent permitted by law, GovernAPI shall not be liable for any indirect, 
              incidental, special, consequential, or punitive damages, including lost profits, 
              data loss, or business interruption.
            </Paragraph>
            <Paragraph>
              Our total liability for any claims shall not exceed the amount paid by you for 
              services during the 12 months preceding the claim.
            </Paragraph>
          </section>

          <section>
            <Title level={2}>Termination</Title>
            <Paragraph>
              Either party may terminate this agreement with 30 days written notice. 
              We may immediately terminate accounts that violate these terms or pose security risks.
            </Paragraph>
            <Paragraph>
              Upon termination, you will lose access to the platform and your data will be 
              deleted according to our data retention policy unless legally required to retain it.
            </Paragraph>
          </section>

          <section>
            <Title level={2}>Contact Information</Title>
            <Paragraph>
              For questions about these Terms of Service, contact us at:
            </Paragraph>
            <Paragraph>
              Email: legal@governapi.com<br />
              Address: [Your Company Address]<br />
              Phone: [Your Phone Number]
            </Paragraph>
          </section>
        </div>
      </Content>
    </Layout>
  )
}
