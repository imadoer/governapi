import { NextResponse } from 'next/server'

export async function GET() {
  return NextResponse.json({
    success: true,
    stats: {
      total_apis: 15,
      by_type: { "REST": 12, "GraphQL": 2, "WebSocket": 1 },
      by_status: { "Active": 13, "Deprecated": 2 },
      recent_discoveries: [
        {
          url: "https://governapi.com/api/threat-monitoring",
          api_type: "REST",
          discovered_at: new Date().toISOString(),
          status: "Active"
        },
        {
          url: "https://governapi.com/api/security-scan", 
          api_type: "REST",
          discovered_at: new Date().toISOString(),
          status: "Active"
        }
      ]
    },
    apis: [
      { url: "https://governapi.com/api/threat-monitoring", api_type: "REST", status: "Active" },
      { url: "https://governapi.com/api/security-scan", api_type: "REST", status: "Active" },
      { url: "https://governapi.com/api/bot-detection", api_type: "REST", status: "Active" },
      { url: "https://governapi.com/api/analytics", api_type: "REST", status: "Active" },
      { url: "https://governapi.com/api/trends", api_type: "REST", status: "Active" },
      { url: "https://governapi.com/api/reports", api_type: "REST", status: "Active" }
    ]
  })
}
