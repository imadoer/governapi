import { NextRequest, NextResponse } from 'next/server'

export async function GET() {
  try {
    const { getLatestSecurityScan } = await import('@/lib/storage/filedb')
    const scanResults = await getLatestSecurityScan()
    
    if (!scanResults) {
      return NextResponse.json({ 
        success: false, 
        message: 'No scan results available. Run a security scan first.',
        results: null
      })
    }
    
    return NextResponse.json({
      success: true,
      results: scanResults
    })
  } catch (error) {
    return NextResponse.json({ 
      error: error.message 
    }, { status: 500 })
  }
}
