import { NextRequest, NextResponse } from 'next/server'
import { Pool } from 'pg'

const pool = new Pool({
  host: 'localhost',
  port: 5432,
  database: 'governapi',
  user: 'governapi_user',
  password: 'newpassword123'
})

export async function GET() {
  try {
    // Get recent high-severity events as notifications
    const result = await pool.query(`
      SELECT created_at, ip, event_type, threat_level, details
      FROM security_events 
      WHERE threat_level IN ('HIGH', 'CRITICAL') 
        AND created_at > NOW() - INTERVAL '7 days'
      ORDER BY created_at DESC 
      LIMIT 20
    `)
    
    return NextResponse.json({
      success: true,
      notifications: result.rows.map(row => ({
        id: `${row.ip}-${row.created_at}`,
        timestamp: row.created_at,
        type: row.event_type,
        severity: row.threat_level,
        message: `${row.threat_level} threat from IP ${row.ip}`,
        ip: row.ip,
        details: row.details
      }))
    })
  } catch (error) {
    console.error('Notifications API error:', error)
    return NextResponse.json({ error: 'Failed to fetch notifications' }, { status: 500 })
  }
}
