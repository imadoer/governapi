import { NextResponse } from 'next/server'

async function sendEmailAlert(email: string, scanResults: any) {
  // Simulate email sending (replace with actual email service)
  const vulnerabilities = scanResults.vulnerabilities || []
  const criticalVulns = vulnerabilities.filter(v => v.severity === 'CRITICAL').length
  const highVulns = vulnerabilities.filter(v => v.severity === 'HIGH').length
  
  const emailContent = {
    to: email,
    subject: `GovernAPI Security Alert - ${vulnerabilities.length} vulnerabilities found`,
    body: `
Security Scan Alert for ${scanResults.target}

Critical: ${criticalVulns}
High: ${highVulns}
Medium: ${vulnerabilities.filter(v => v.severity === 'MEDIUM').length}
Low: ${vulnerabilities.filter(v => v.severity === 'LOW').length}

Overall Risk: ${scanResults.overall_risk}

View full report at: https://governapi.com/dashboard
    `
  }
  
  // Log the alert (in production, integrate with SendGrid, AWS SES, etc.)
  console.log('EMAIL ALERT SENT:', emailContent)
  return true
}

export async function POST() {
  try {
    const scanResults = global.lastScanResults
    const alertConfigs = global.alertConfigs || []
    
    if (!scanResults) {
      return NextResponse.json({ message: 'No scan results to process' })
    }
    
    const vulnerabilities = scanResults.vulnerabilities || []
    const hasCritical = vulnerabilities.some(v => v.severity === 'CRITICAL')
    const hasHigh = vulnerabilities.some(v => v.severity === 'HIGH')
    const hasMedium = vulnerabilities.some(v => v.severity === 'MEDIUM')
    
    let alertsSent = 0
    
    for (const config of alertConfigs) {
      if (!config.enabled) continue
      
      let shouldAlert = false
      
      if (config.severity_threshold === 'CRITICAL' && hasCritical) shouldAlert = true
      if (config.severity_threshold === 'HIGH' && (hasCritical || hasHigh)) shouldAlert = true
      if (config.severity_threshold === 'MEDIUM' && (hasCritical || hasHigh || hasMedium)) shouldAlert = true
      if (config.severity_threshold === 'LOW' && vulnerabilities.length > 0) shouldAlert = true
      
      if (shouldAlert) {
        await sendEmailAlert(config.email, scanResults)
        alertsSent++
      }
    }
    
    return NextResponse.json({
      alerts_sent: alertsSent,
      scan_target: scanResults.target,
      vulnerabilities_found: vulnerabilities.length,
      timestamp: new Date().toISOString()
    })
    
  } catch (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
