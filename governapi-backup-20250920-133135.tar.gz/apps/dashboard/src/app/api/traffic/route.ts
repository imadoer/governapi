import { NextRequest, NextResponse } from 'next/server'
import { supabase } from '@/lib/db/supabase'

export async function POST(req: NextRequest) {
  try {
    const { apiId, request: requestData } = await req.json()
    
    // Real traffic analysis
    const threats = []
    
    // SQL Injection detection
    if (requestData.query && /('|(\\)|;|union|select|insert|update|delete|drop)/i.test(requestData.query)) {
      threats.push({
        type: 'SQL_INJECTION',
        severity: 'HIGH',
        details: 'Potential SQL injection in query parameters'
      })
    }
    
    // XSS detection
    if (requestData.body && /<script|javascript:|on\w+=/i.test(requestData.body)) {
      threats.push({
        type: 'XSS',
        severity: 'HIGH', 
        details: 'Potential XSS in request body'
      })
    }
    
    // Rate limiting check
    const recentRequests = await supabase
      .from('traffic_logs')
      .select('created_at')
      .eq('source_ip', requestData.ip)
      .gte('created_at', new Date(Date.now() - 60000).toISOString())
    
    if (recentRequests.data && recentRequests.data.length > 100) {
      threats.push({
        type: 'RATE_LIMIT_EXCEEDED',
        severity: 'MEDIUM',
        details: `${recentRequests.data.length} requests in last minute`
      })
    }
    
    // Log traffic
    await supabase
      .from('traffic_logs')
      .insert({
        api_id: apiId,
        source_ip: requestData.ip,
        method: requestData.method,
        path: requestData.path,
        user_agent: requestData.headers?.['user-agent'],
        threats_detected: threats.length,
        blocked: threats.some(t => t.severity === 'HIGH')
      })
    
    return NextResponse.json({
      allowed: !threats.some(t => t.severity === 'HIGH'),
      threats,
      action: threats.some(t => t.severity === 'HIGH') ? 'BLOCK' : 'ALLOW'
    })
    
  } catch (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
