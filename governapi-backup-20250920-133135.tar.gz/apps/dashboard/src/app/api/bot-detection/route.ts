import { NextRequest, NextResponse } from 'next/server'

export async function GET() {
  try {
    const { getTrafficStats } = await import('@/lib/storage/filedb')
    const stats = await getTrafficStats()
    
    return NextResponse.json({
      success: true,
      ...stats
    })
  } catch (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
