import { NextRequest, NextResponse } from 'next/server'

interface User {
  id: string
  email: string
  name: string
  role: 'admin' | 'security_analyst' | 'auditor' | 'viewer'
  created_at: string
  last_login: string
  active: boolean
}

export async function GET() {
  try {
    // Get users from global storage (in production this would be database)
    const users = global.users || [
      {
        id: '1',
        email: 'demo@governapi.com',
        name: 'Demo Admin',
        role: 'admin',
        created_at: new Date().toISOString(),
        last_login: new Date().toISOString(),
        active: true
      }
    ]
    
    return NextResponse.json({ users })
  } catch (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  try {
    const { email, name, role } = await req.json()
    
    if (!email || !name || !role) {
      return NextResponse.json({ error: 'Email, name, and role are required' }, { status: 400 })
    }
    
    const newUser: User = {
      id: `user_${Date.now()}`,
      email,
      name,
      role,
      created_at: new Date().toISOString(),
      last_login: 'Never',
      active: true
    }
    
    if (!global.users) global.users = []
    global.users.push(newUser)
    
    return NextResponse.json({ success: true, user: newUser })
  } catch (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
