import { NextRequest, NextResponse } from 'next/server'
import { triggerScan, getScanStatus } from '@/lib/scanner/integration'

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    
    // Map the form data to scanner request
    const scanRequest = {
      tenantId: 'default', // In production, get from session
      targets: [{
        host: body.target || 'localhost',
        portRange: [80, 443] as [number, number],
        protocols: ['http', 'https'] as ('http' | 'https')[]
      }],
      scanType: body.type || 'full' as any
    }
    
    const result = await triggerScan(scanRequest)
    
    return NextResponse.json({ 
      success: true,
      scan: result 
    })
  } catch (error) {
    console.error('Scan API error:', error)
    return NextResponse.json({ 
      success: false,
      error: 'Failed to start scan' 
    }, { status: 500 })
  }
}

export async function GET(req: NextRequest) {
  const scanId = req.nextUrl.searchParams.get('scanId')
  
  if (scanId) {
    const status = await getScanStatus(scanId)
    return NextResponse.json({ scan: status })
  }
  
  // Return mock scan history
  const scans = [
    {
      id: 'SCAN-001',
      target: 'api.example.com',
      type: 'API Security Audit',
      status: 'completed',
      findings: { critical: 2, high: 5, medium: 12, low: 23 },
      created: new Date().toISOString()
    }
  ]
  
  return NextResponse.json({ scans })
}
