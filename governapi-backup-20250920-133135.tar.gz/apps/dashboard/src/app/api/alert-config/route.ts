import { NextRequest, NextResponse } from 'next/server'

export async function GET() {
  try {
    const { promises: fs } = await import('fs')
    const { join } = await import('path')
    
    const DATA_DIR = join(process.cwd(), 'data')
    const configFile = join(DATA_DIR, 'alert_config.json')
    
    let config = {
      webhook_triggers: {
        critical_threshold: 1,
        high_threshold: 2,
        medium_threshold: 5,
        response_time_threshold: 10000
      },
      notification_settings: {
        enabled: true,
        include_performance: true,
        include_owasp_details: true
      }
    }
    
    try {
      const data = await fs.readFile(configFile, 'utf8')
      config = { ...config, ...JSON.parse(data) }
    } catch {}
    
    return NextResponse.json({ config })
  } catch (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  try {
    const { config } = await req.json()
    
    const { promises: fs } = await import('fs')
    const { join } = await import('path')
    
    const DATA_DIR = join(process.cwd(), 'data')
    
    // Ensure data directory exists
    try {
      await fs.access(DATA_DIR)
    } catch {
      await fs.mkdir(DATA_DIR, { recursive: true })
    }
    
    const configFile = join(DATA_DIR, 'alert_config.json')
    await fs.writeFile(configFile, JSON.stringify(config, null, 2))
    
    return NextResponse.json({ success: true, config })
  } catch (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
