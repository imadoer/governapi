import { NextRequest, NextResponse } from 'next/server'

export async function POST(req: NextRequest) {
  return NextResponse.json({ 
    message: 'Test endpoint response',
    timestamp: Date.now()
  })
}

export async function GET(req: NextRequest) {
  return NextResponse.json({ 
    message: 'Test endpoint response',
    timestamp: Date.now()
  })
}
