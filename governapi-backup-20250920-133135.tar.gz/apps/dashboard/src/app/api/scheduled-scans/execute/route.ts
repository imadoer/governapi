import { NextRequest, NextResponse } from 'next/server'

export async function POST() {
  try {
    const { getScheduledScans, updateScheduledScan } = await import('@/lib/storage/filedb')
    const scans = await getScheduledScans()
    
    const now = new Date()
    const executedScans = []
    
    for (const scan of scans) {
      if (scan.enabled && new Date(scan.next_run) <= now) {
        try {
          // Execute security scan
          const scanResponse = await fetch(`${process.env.NEXTAUTH_URL || 'https://governapi.com'}/api/security-scan`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ target_url: scan.target_url })
          })
          
          if (scanResponse.ok) {
            // Update scheduled scan with new run time
            const nextRun = calculateNextRun(scan.frequency)
            await updateScheduledScan(scan.id, {
              last_run: now.toISOString(),
              next_run: nextRun
            })
            
            executedScans.push({
              scan_id: scan.id,
              name: scan.name,
              target: scan.target_url,
              status: 'success'
            })
          }
        } catch (error) {
          executedScans.push({
            scan_id: scan.id,
            name: scan.name,
            target: scan.target_url,
            status: 'failed',
            error: error.message
          })
        }
      }
    }
    
    return NextResponse.json({
      success: true,
      executed_scans: executedScans,
      total_executed: executedScans.length
    })
  } catch (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}

function calculateNextRun(frequency: string): string {
  const now = new Date()
  switch (frequency) {
    case 'daily':
      now.setDate(now.getDate() + 1)
      break
    case 'weekly':
      now.setDate(now.getDate() + 7)
      break
    case 'monthly':
      now.setMonth(now.getMonth() + 1)
      break
  }
  return now.toISOString()
}
