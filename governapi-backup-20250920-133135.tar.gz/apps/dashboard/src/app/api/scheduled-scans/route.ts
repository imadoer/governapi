import { NextRequest, NextResponse } from 'next/server'

interface ScheduledScan {
  id: string
  name: string
  target_url: string
  frequency: 'daily' | 'weekly' | 'monthly'
  enabled: boolean
  last_run: string | null
  next_run: string
  created_at: string
}

export async function GET() {
  try {
    const { getScheduledScans } = await import('@/lib/storage/filedb')
    const scans = await getScheduledScans()
    
    return NextResponse.json({ scans })
  } catch (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  try {
    const { name, target_url, frequency } = await req.json()
    
    if (!name || !target_url || !frequency) {
      return NextResponse.json({ error: 'Name, target URL, and frequency are required' }, { status: 400 })
    }
    
    const scheduledScan: ScheduledScan = {
      id: `scan_${Date.now()}`,
      name,
      target_url,
      frequency,
      enabled: true,
      last_run: null,
      next_run: calculateNextRun(frequency),
      created_at: new Date().toISOString()
    }
    
    const { saveScheduledScan } = await import('@/lib/storage/filedb')
    await saveScheduledScan(scheduledScan)
    
    return NextResponse.json({ success: true, scan: scheduledScan })
  } catch (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}

function calculateNextRun(frequency: string): string {
  const now = new Date()
  switch (frequency) {
    case 'daily':
      now.setDate(now.getDate() + 1)
      break
    case 'weekly':
      now.setDate(now.getDate() + 7)
      break
    case 'monthly':
      now.setMonth(now.getMonth() + 1)
      break
  }
  return now.toISOString()
}
