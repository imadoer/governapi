import { NextRequest, NextResponse } from 'next/server'
import { supabase } from '@/lib/db/supabase'

export async function POST(req: NextRequest) {
  try {
    const formData = await req.formData()
    const file = formData.get('file') as File
    const content = await file.text()
    const spec = JSON.parse(content)
    
    // Parse OpenAPI spec and create APIs
    const apis = []
    const baseUrl = spec.servers?.[0]?.url || 'http://localhost'
    
    for (const [path, methods] of Object.entries(spec.paths || {})) {
      for (const [method, details] of Object.entries(methods as any)) {
        if (['get', 'post', 'put', 'delete', 'patch'].includes(method)) {
          const { data: api } = await supabase
            .from('apis')
            .insert({
              name: details.summary || `${method.toUpperCase()} ${path}`,
              endpoint: `${baseUrl}${path}`,
              type: 'REST',
              classification: details['x-classification'] || 'unclassified',
              environment: 'production',
              metadata: {
                method: method.toUpperCase(),
                description: details.description,
                parameters: details.parameters,
                responses: details.responses
              }
            })
            .select()
            .single()
          
          if (api) apis.push(api)
        }
      }
    }
    
    return NextResponse.json({ success: true, imported: apis.length, apis })
  } catch (error) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 })
  }
}
