import { NextRequest, NextResponse } from 'next/server'

export async function GET() {
  try {
    const { promises: fs } = await import('fs')
    const { join } = await import('path')
    
    const DATA_DIR = join(process.cwd(), 'data')
    
    // Read scan history
    const historyFile = join(DATA_DIR, 'scan_history.json')
    let scanHistory = []
    
    try {
      const data = await fs.readFile(historyFile, 'utf8')
      scanHistory = JSON.parse(data)
    } catch {
      return NextResponse.json({ trends: [], message: 'No historical data available' })
    }

    // Calculate trends
    const trends = scanHistory.map(scan => ({
      timestamp: scan.timestamp,
      target: scan.target,
      overall_risk: scan.overall_risk,
      vulnerability_count: scan.vulnerabilities?.length || 0,
      critical_count: scan.vulnerabilities?.filter(v => v.severity === 'CRITICAL').length || 0,
      high_count: scan.vulnerabilities?.filter(v => v.severity === 'HIGH').length || 0,
      medium_count: scan.vulnerabilities?.filter(v => v.severity === 'MEDIUM').length || 0,
      low_count: scan.vulnerabilities?.filter(v => v.severity === 'LOW').length || 0,
      response_time: scan.response_time_ms || 0,
      owasp_categories: scan.owasp_findings?.filter(f => f.vulnerable).map(f => f.owasp_category) || []
    }))

    // Calculate risk score progression
    const riskScores = trends.map(t => {
      let score = 0
      score += (t.critical_count * 10)
      score += (t.high_count * 5)
      score += (t.medium_count * 2)
      score += (t.low_count * 1)
      return { timestamp: t.timestamp, risk_score: score, target: t.target }
    })

    // OWASP category frequency over time
    const owaspTrends = {}
    trends.forEach(scan => {
      scan.owasp_categories.forEach(category => {
        if (!owaspTrends[category]) owaspTrends[category] = []
        owaspTrends[category].push({
          timestamp: scan.timestamp,
          count: 1
        })
      })
    })

    return NextResponse.json({
      trends: trends.sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()),
      risk_progression: riskScores,
      owasp_trends: owaspTrends,
      summary: {
        total_scans: trends.length,
        avg_vulnerabilities: trends.length > 0 ? Math.round(trends.reduce((sum, t) => sum + t.vulnerability_count, 0) / trends.length) : 0,
        risk_trend: riskScores.length > 1 ? (riskScores[riskScores.length - 1].risk_score > riskScores[0].risk_score ? 'increasing' : 'decreasing') : 'stable'
      }
    })
  } catch (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
