import { NextRequest, NextResponse } from 'next/server'
import { Pool } from 'pg'

const pool = new Pool({
  host: 'localhost',
  port: 5432,
  database: 'governapi',
  user: 'governapi_user',
  password: 'newpassword123'
})

export async function GET() {
  try {
    // Generate reports from security_events and blocked_ips tables
    const result = await pool.query(`
      SELECT 
        DATE_TRUNC('day', created_at) as report_date,
        COUNT(*) as total_events,
        COUNT(*) FILTER (WHERE event_type = 'THREAT_BLOCKED') as threats_blocked,
        COUNT(*) FILTER (WHERE event_type = 'IP_UNBLOCKED') as ips_unblocked,
        COUNT(DISTINCT ip) as unique_ips
      FROM security_events 
      WHERE created_at > NOW() - INTERVAL '30 days'
      GROUP BY DATE_TRUNC('day', created_at)
      ORDER BY report_date DESC
      LIMIT 30
    `)
    
    return NextResponse.json({
      success: true,
      reports: result.rows.map(row => ({
        date: row.report_date,
        totalEvents: parseInt(row.total_events),
        threatsBlocked: parseInt(row.threats_blocked),
        ipsUnblocked: parseInt(row.ips_unblocked),
        uniqueIps: parseInt(row.unique_ips)
      }))
    })
  } catch (error) {
    console.error('Reports API error:', error)
    return NextResponse.json({ error: 'Failed to generate reports' }, { status: 500 })
  }
}
