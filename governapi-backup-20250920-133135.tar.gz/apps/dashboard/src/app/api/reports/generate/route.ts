import { NextRequest, NextResponse } from 'next/server'

export async function POST(req: NextRequest) {
  try {
    const { report_type = 'security' } = await req.json()
    
    // Get real data from your platform's global storage
    const scanResults = global.lastScanResults
    const discoveredAPIs = global.discoveredAPIs || []
    const trafficLogs = global.trafficLogs || []
    const alertConfigs = global.alertConfigs || []
    const webhookConfigs = global.webhookConfigs || []
    
    // Calculate real metrics from actual data
    const totalAPIs = discoveredAPIs.length
    const totalVulnerabilities = scanResults?.vulnerabilities?.length || 0
    const criticalVulns = scanResults?.vulnerabilities?.filter(v => v.severity === 'CRITICAL').length || 0
    const highVulns = scanResults?.vulnerabilities?.filter(v => v.severity === 'HIGH').length || 0
    
    // Calculate security score based on actual vulnerabilities found
    let securityScore = 100
    if (totalVulnerabilities > 0) {
      securityScore -= (criticalVulns * 25)
      securityScore -= (highVulns * 15)
      securityScore -= ((totalVulnerabilities - criticalVulns - highVulns) * 5)
      securityScore = Math.max(0, securityScore)
    }
    
    // Real bot detection metrics from traffic logs
    const totalTraffic = trafficLogs.length
    const botTraffic = trafficLogs.filter(log => log.is_bot).length
    const blockedBots = trafficLogs.filter(log => log.blocked).length
    
    // Calculate compliance based on actual security findings
    const hasHttps = scanResults?.ssl_analysis?.certificate_valid !== false
    const securityHeadersCount = scanResults?.headers_analysis?.security_headers_present?.length || 0
    const complianceFactors = [
      hasHttps ? 25 : 0,
      securityHeadersCount > 3 ? 25 : (securityHeadersCount * 6),
      totalVulnerabilities === 0 ? 30 : Math.max(0, 30 - (totalVulnerabilities * 5)),
      alertConfigs.length > 0 ? 20 : 0
    ]
    const complianceScore = Math.min(100, complianceFactors.reduce((a, b) => a + b, 0))
    
    const reportData = {
      report_type,
      generated_at: new Date().toISOString(),
      metrics: {
        total_apis: totalAPIs,
        security_score: securityScore,
        compliance_score: complianceScore,
        total_vulnerabilities: totalVulnerabilities,
        critical_vulnerabilities: criticalVulns,
        high_vulnerabilities: highVulns,
        bots_blocked: blockedBots,
        total_traffic: totalTraffic,
        bot_detection_rate: totalTraffic > 0 ? Math.round((botTraffic / totalTraffic) * 100) : 0
      },
      scan_summary: scanResults ? {
        target: scanResults.target,
        overall_risk: scanResults.overall_risk,
        scan_date: scanResults.timestamp,
        owasp_findings: scanResults.owasp_findings?.length || 0
      } : null,
      recommendations: generateRecommendations(scanResults, totalVulnerabilities, criticalVulns, hasHttps)
    }
    
    return NextResponse.json({
      success: true,
      report_data: reportData
    })
    
  } catch (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}

function generateRecommendations(scanResults: any, totalVulns: number, criticalVulns: number, hasHttps: boolean) {
  const recommendations = []
  
  if (criticalVulns > 0) {
    recommendations.push('Immediately address critical security vulnerabilities')
  }
  
  if (!hasHttps) {
    recommendations.push('Implement HTTPS with valid SSL/TLS certificates')
  }
  
  if (scanResults?.headers_analysis?.security_headers_missing?.length > 0) {
    recommendations.push('Configure missing security headers for enhanced protection')
  }
  
  if (totalVulns === 0) {
    recommendations.push('Continue regular security assessments to maintain security posture')
  } else {
    recommendations.push('Review and remediate identified security vulnerabilities')
  }
  
  if (!scanResults) {
    recommendations.push('Run security scans to assess API vulnerabilities')
  }
  
  return recommendations
}
