import { NextRequest, NextResponse } from 'next/server'
import { rateLimiter } from '@/lib/rate-limiter'

export async function GET() {
  try {
    const stats = rateLimiter.getStats()
    
    const { promises: fs } = await import('fs')
    const { join } = await import('path')
    const DATA_DIR = join(process.cwd(), 'data')
    const configFile = join(DATA_DIR, 'rate_limit_config.json')
    
    let config = {
      enabled: true,
      windowMs: 60000, // 1 minute
      maxRequests: 100,
      blockDuration: 300000, // 5 minutes
      skipPaths: ['/api/auth/', '/api/webhooks/'],
      alertThreshold: 50 // Alert when 50% of limit reached
    }
    
    try {
      const data = await fs.readFile(configFile, 'utf8')
      config = { ...config, ...JSON.parse(data) }
    } catch {}
    
    return NextResponse.json({ 
      config,
      stats,
      currentTime: Date.now()
    })
  } catch (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  try {
    const { config } = await req.json()
    
    // Update rate limiter configuration
    rateLimiter.updateConfig({
      windowMs: config.windowMs,
      maxRequests: config.maxRequests,
      blockDuration: config.blockDuration
    })
    
    // Save configuration
    const { promises: fs } = await import('fs')
    const { join } = await import('path')
    const DATA_DIR = join(process.cwd(), 'data')
    
    try {
      await fs.access(DATA_DIR)
    } catch {
      await fs.mkdir(DATA_DIR, { recursive: true })
    }
    
    const configFile = join(DATA_DIR, 'rate_limit_config.json')
    await fs.writeFile(configFile, JSON.stringify(config, null, 2))
    
    return NextResponse.json({ success: true, config })
  } catch (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
