import { NextRequest, NextResponse } from 'next/server'
import { supabase } from '@/lib/db/supabase'
import { runFullGovernAPIScanner } from '@/lib/scanner/full-scanner-integration'

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { target, scanType, environment } = body
    
    // Create API record
    let { data: api } = await supabase
      .from('apis')
      .select('*')
      .eq('endpoint', target)
      .single()
    
    if (!api) {
      const { data: newApi } = await supabase
        .from('apis')
        .insert({
          name: new URL(target).hostname,
          endpoint: target,
          type: 'REST',
          classification: 'unclassified',
          environment: environment
        })
        .select()
        .single()
      
      api = newApi
    }
    
    // Create scan
    const { data: scan } = await supabase
      .from('scans')
      .insert({
        api_id: api.id,
        scan_type: scanType,
        status: 'running'
      })
      .select()
      .single()
    
    // Run YOUR FULL SCANNER with all features
    runFullGovernAPIScanner(scan.id, target, scanType)
      .catch(err => console.error('Full scanner error:', err));
    
    return NextResponse.json({ success: true, scan });
  } catch (error) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function GET() {
  const { data: scans } = await supabase
    .from('scans')
    .select('*, apis(*)')
    .order('created_at', { ascending: false })
  
  return NextResponse.json({ scans: scans || [] });
}
