import { NextRequest, NextResponse } from 'next/server'

export async function POST(req: NextRequest) {
  try {
    const { webhook_url, message, channel } = await req.json()
    
    const slackMessage = {
      channel: channel || '#security-alerts',
      username: 'GovernAPI',
      icon_emoji: ':shield:',
      text: message,
      attachments: [{
        color: 'danger',
        fields: [{
          title: 'API Security Alert',
          value: message,
          short: false
        }]
      }]
    }

    const response = await fetch(webhook_url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(slackMessage)
    })

    return NextResponse.json({ success: response.ok })
  } catch (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
