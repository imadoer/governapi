import { NextRequest, NextResponse } from 'next/server'
import { Pool } from 'pg'

const pool = new Pool({
  host: 'localhost',
  port: 5432,
  database: 'governapi',
  user: 'governapi_user',
  password: 'newpassword123'
})

export async function GET() {
  try {
    const result = await pool.query(`
      SELECT 
        COUNT(*) as total_threats,
        COUNT(*) FILTER (WHERE created_at > NOW() - INTERVAL '24 hours') as threats_today,
        COUNT(*) FILTER (WHERE threat_level = 'CRITICAL') as critical_threats
      FROM security_events 
      WHERE event_type = 'THREAT_BLOCKED'
    `)
    
    const stats = result.rows[0]
    return NextResponse.json({
      total_threats: parseInt(stats.total_threats || '0'),
      threats_today: parseInt(stats.threats_today || '0'), 
      critical_threats: parseInt(stats.critical_threats || '0')
    })
  } catch (error) {
    console.error('Analytics threats API error:', error)
    return NextResponse.json({ error: 'Failed to fetch threat analytics' }, { status: 500 })
  }
}
