import { NextRequest, NextResponse } from 'next/server'
import { supabase } from '@/lib/db/supabase'

export async function GET(req: NextRequest) {
  try {
    // Get API usage data
    const { data: apis } = await supabase
      .from('apis')
      .select('*')
    
    const { data: scans } = await supabase
      .from('scans')
      .select('*')
      .gte('created_at', new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString())
    
    // Calculate costs (simplified - your cost-calculator.ts has the full logic)
    const costs = {
      total: 0,
      byApi: {},
      savings: 0,
      threats_blocked: 0
    }
    
    // Estimate based on scans and violations
    for (const scan of scans || []) {
      const baseCost = 0.001 // $0.001 per scan
      const threatCost = (scan.results?.vulnerabilities?.critical || 0) * 10 // $10 per critical threat blocked
      
      costs.total += baseCost
      costs.savings += threatCost
      costs.threats_blocked += scan.results?.vulnerabilities?.critical || 0
    }
    
    return NextResponse.json({
      monthly_cost: costs.total * 30,
      monthly_savings: costs.savings,
      threats_blocked: costs.threats_blocked,
      roi_percentage: (costs.savings / (costs.total || 1)) * 100
    })
  } catch (error) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 })
  }
}
