import { NextRequest, NextResponse } from 'next/server'
import { supabase } from '@/lib/db/supabase'

export async function GET() {
  try {
    const { data: violations } = await supabase
      .from('violations')
      .select('*')
      .eq('status', 'active')
    
    const { data: policies } = await supabase
      .from('policies')
      .select('*')
      .eq('enabled', true)
    
    // Calculate compliance score
    const totalChecks = (policies?.length || 1) * 10
    const violations_count = violations?.length || 0
    const score = Math.max(0, Math.round(((totalChecks - violations_count) / totalChecks) * 100))
    
    return NextResponse.json({
      overall_score: score,
      frameworks: {
        'SOC2': Math.min(100, score + 5),
        'GDPR': Math.min(100, score - 2),
        'PCI-DSS': Math.min(100, score - 10),
        'HIPAA': Math.min(100, score + 8)
      },
      violations: violations_count,
      policies: policies?.length || 0
    })
  } catch (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
