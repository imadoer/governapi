import { NextRequest } from 'next/server'
import { threatService } from '@/lib/services/threat-service'

export async function GET() {
  try {
    // Get recent security events from the database
    const { Pool } = require('pg')
    const pool = new Pool({
      host: 'localhost',
      port: 5432,
      database: 'governapi',
      user: 'governapi_user',
      password: 'newpassword123'
    })
    
    const result = await pool.query(`
      SELECT created_at, ip, event_type, threat_level, details
      FROM security_events 
      ORDER BY created_at DESC 
      LIMIT 10
    `)
    
    return Response.json({
      success: true,
      events: result.rows.map(row => ({
        time: row.created_at,
        ip: row.ip,
        eventType: row.event_type,
        threatLevel: row.threat_level,
        details: row.details,
        status: row.event_type === 'THREAT_BLOCKED' ? 'Blocked' : 'Unblocked'
      }))
    })
  } catch (error) {
    console.error('Security events API error:', error)
    return Response.json({ error: 'Failed to fetch security events' }, { status: 500 })
  }
}
