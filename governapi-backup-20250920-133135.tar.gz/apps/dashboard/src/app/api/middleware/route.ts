import { NextRequest, NextResponse } from 'next/server'
import { supabase } from '@/lib/db/supabase'

// This middleware intercepts actual API traffic
export async function POST(req: NextRequest) {
  try {
    const { target_url, request_data } = await req.json()
    
    // Forward the original request
    const originalResponse = await fetch(target_url, {
      method: request_data.method,
      headers: request_data.headers,
      body: request_data.body
    })
    
    // Analyze the traffic in real-time
    const threats = await analyzeRealTimeTraffic(request_data)
    const botScore = await analyzeBotBehavior(request_data)
    
    // Log everything to database
    await supabase
      .from('live_traffic')
      .insert({
        url: target_url,
        method: request_data.method,
        source_ip: request_data.ip,
        threats_detected: threats.length,
        bot_score: botScore,
        response_time: Date.now() - request_data.timestamp,
        blocked: threats.some(t => t.severity === 'HIGH') || botScore > 80
      })
    
    // Return response or block
    if (threats.some(t => t.severity === 'HIGH') || botScore > 80) {
      return NextResponse.json({ error: 'Request blocked by security policy' }, { status: 403 })
    }
    
    return new NextResponse(originalResponse.body, {
      status: originalResponse.status,
      headers: originalResponse.headers
    })
    
  } catch (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}

async function analyzeRealTimeTraffic(request: any) {
  const threats = []
  
  // Advanced SQL injection detection
  const sqlPatterns = [
    /('|(\\)|;|union|select|insert|update|delete|drop|exec|sp_|xp_)/i,
    /(\w+)\s*(=)\s*(\w+)\s*(or|and)\s*(\w+)\s*(=)\s*(\w+)/i,
    /(union|select|insert|update|delete).+(from|into|set|where)/i
  ]
  
  const payload = JSON.stringify(request.body || '') + (request.query || '')
  
  for (const pattern of sqlPatterns) {
    if (pattern.test(payload)) {
      threats.push({
        type: 'SQL_INJECTION',
        severity: 'HIGH',
        pattern: pattern.source,
        details: 'Advanced SQL injection pattern detected'
      })
    }
  }
  
  // XSS detection with multiple vectors
  const xssPatterns = [
    /<script[^>]*>.*?<\/script>/gi,
    /javascript:/gi,
    /on\w+\s*=\s*["\'].*?["\']/gi,
    /<iframe[^>]*src\s*=\s*["\'].*?["\'][^>]*>/gi
  ]
  
  for (const pattern of xssPatterns) {
    if (pattern.test(payload)) {
      threats.push({
        type: 'XSS',
        severity: 'HIGH',
        pattern: pattern.source,
        details: 'Cross-site scripting attempt detected'
      })
    }
  }
  
  return threats
}

async function analyzeBotBehavior(request: any) {
  let score = 0
  
  // User agent analysis
  const ua = request.headers?.['user-agent'] || ''
  const botUserAgents = ['bot', 'crawler', 'spider', 'scraper', 'python-requests', 'curl', 'wget']
  
  if (botUserAgents.some(bot => ua.toLowerCase().includes(bot))) {
    score += 40
  }
  
  // Request frequency analysis
  const { data: recentRequests } = await supabase
    .from('live_traffic')
    .select('created_at')
    .eq('source_ip', request.ip)
    .gte('created_at', new Date(Date.now() - 60000).toISOString())
  
  const requestCount = recentRequests?.length || 0
  if (requestCount > 100) score += 50
  else if (requestCount > 50) score += 30
  else if (requestCount > 20) score += 10
  
  // Request pattern analysis
  if (!request.headers?.['accept']) score += 20
  if (!request.headers?.['accept-language']) score += 15
  if (request.headers?.['user-agent'] === '') score += 30
  
  return score
}
