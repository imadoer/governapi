import { NextRequest } from 'next/server'
import { threatDetector } from '@/lib/threat-detection'
import { threatService } from '@/lib/services/threat-service'

// Request counting for this API route
const requestCounts = new Map<string, { count: number; lastReset: number }>()

function getRequestCount(ip: string): number {
  const now = Date.now()
  const existing = requestCounts.get(ip)
  
  if (!existing || now - existing.lastReset > 60000) {
    requestCounts.set(ip, { count: 1, lastReset: now })
    return 1
  }
  
  existing.count++
  return existing.count
}

export async function POST(req: NextRequest) {
  try {
    const { url, userAgent, ip } = await req.json()
    
    console.log(`API THREAT CHECK: Analyzing ${ip} - ${userAgent}`)
    
    // Check if already blocked in database (real-time check)
    const blockedIPs = await threatService.getBlockedIPs()
    const existingBlock = blockedIPs.find(blocked => blocked.ip === ip)
    
    if (existingBlock) {
      console.log(`API THREAT CHECK: IP ${ip} already blocked in database`)
      return Response.json({ 
        blocked: true, 
        reason: existingBlock.reason,
        threatLevel: existingBlock.threatLevel,
        remainingMs: existingBlock.remainingMs
      })
    }
    
    // Get request count for this IP
    const requestCount = getRequestCount(ip)
    
    // Analyze threat with full pattern detection
    const analysis = threatDetector.analyzeThreat(url, userAgent, ip, requestCount)
    
    console.log(`API THREAT CHECK: Analysis result for ${ip}:`, {
      shouldBlock: analysis.shouldBlock,
      threatLevel: analysis.threatLevel,
      threats: analysis.threats,
      total: analysis.total
    })
    
    if (analysis.shouldBlock) {
      // Direct database save - no fetch calls needed!
      await threatService.saveBlockedIP(
        ip,
        `Threat detected: ${analysis.threats.join(", ")}`,
        analysis.blockDuration,
        analysis.threatLevel,
        analysis.threats
      )
      
      console.log(`API THREAT CHECK: IP ${ip} blocked and saved to database`)
      
      return Response.json({ 
        blocked: true, 
        reason: `Threat detected: ${analysis.threats.join(", ")}`,
        threatLevel: analysis.threatLevel,
        blockDuration: analysis.blockDuration,
        threats: analysis.threats
      })
    }
    
    return Response.json({ 
      blocked: false,
      threatLevel: analysis.threatLevel,
      score: analysis.total
    })
    
  } catch (error) {
    console.error('API THREAT CHECK: Error processing request:', error)
    return Response.json({ blocked: false, error: 'Processing failed' }, { status: 500 })
  }
}
