import { NextRequest, NextResponse } from 'next/server'
import { threatService } from '@/lib/services/threat-service'
import { Pool } from 'pg'

const pool = new Pool({
  host: 'localhost',
  port: 5432,
  database: 'governapi',
  user: 'governapi_user',
  password: 'newpassword123'
})

export async function GET() {
  try {
    const blockedIPs = await threatService.getBlockedIPs()
    const stats = await threatService.getStats()
    
    // Get recent security events for the dashboard
    const eventsResult = await pool.query(`
      SELECT created_at, ip, event_type, threat_level, details
      FROM security_events 
      ORDER BY created_at DESC 
      LIMIT 10
    `)
    
    const recentThreats = eventsResult.rows.map(row => ({
      ip: row.ip,
      timestamp: row.created_at,
      eventType: row.event_type,
      threatLevel: row.threat_level,
      details: row.details,
      status: row.event_type === 'THREAT_BLOCKED' ? 'Blocked' : 'Unblocked'
    }))
    
    return NextResponse.json({
      success: true,
      data: {
        blockedIPs,
        stats,
        recentThreats
      }
    })
  } catch (error) {
    console.error('Threat monitoring API error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch threat monitoring data' }, 
      { status: 500 }
    )
  }
}
