import { NextRequest, NextResponse } from 'next/server'
import { threatService } from '@/lib/services/threat-service'

export async function POST(req: NextRequest) {
  try {
    const { ip } = await req.json()
    
    if (!ip) {
      return NextResponse.json({ error: "IP address required" }, { status: 400 })
    }

    await threatService.unblockIP(ip)
    
    return NextResponse.json({ 
      success: true, 
      message: `IP ${ip} has been unblocked successfully` 
    })
  } catch (error) {
    console.error('Unblock error:', error)
    return NextResponse.json(
      { error: 'Failed to unblock IP' }, 
      { status: 500 }
    )
  }
}
