import { NextRequest, NextResponse } from 'next/server'
import { threatService } from '@/lib/services/threat-service'

export async function POST(req: NextRequest) {
  try {
    const { ip, reason, duration, threatLevel, threats } = await req.json()
    
    await threatService.saveBlockedIP(ip, reason, duration, threatLevel, threats)
    
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Save threat error:', error)
    return NextResponse.json({ error: 'Failed to save threat data' }, { status: 500 })
  }
}
