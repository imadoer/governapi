import { NextRequest, NextResponse } from 'next/server'
import { getDatabase } from '../../../../lib/database/connection'
import jwt from 'jsonwebtoken'

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production'

function getUserFromToken(req: NextRequest) {
  const token = req.cookies.get('auth-token')?.value
  if (!token) return null
  
  try {
    return jwt.verify(token, JWT_SECRET) as any
  } catch {
    return null
  }
}

export async function GET(req: NextRequest) {
  try {
    const user = getUserFromToken(req)
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const db = await getDatabase()
    const apis = await db.all('SELECT * FROM apis WHERE user_id = ? ORDER BY created_at DESC', [user.userId])
    
    return NextResponse.json({ apis })
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch APIs' }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  try {
    const user = getUserFromToken(req)
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { name, base_url, description } = await req.json()
    
    if (!name || !base_url) {
      return NextResponse.json({ error: 'Name and base URL required' }, { status: 400 })
    }

    const db = await getDatabase()
    const result = await db.run(
      'INSERT INTO apis (name, base_url, description, user_id) VALUES (?, ?, ?, ?)',
      [name, base_url, description || '', user.userId]
    )

    // Start monitoring the API (simplified implementation)
    setTimeout(async () => {
      try {
        const healthCheck = await fetch(base_url, { method: 'HEAD' })
        const healthScore = healthCheck.ok ? 95 : 45
        
        await db.run(
          'UPDATE apis SET health_score = ?, last_scan = CURRENT_TIMESTAMP WHERE id = ?',
          [healthScore, result.lastID]
        )
      } catch (error) {
        await db.run(
          'UPDATE apis SET health_score = ?, last_scan = CURRENT_TIMESTAMP WHERE id = ?',
          [25, result.lastID]
        )
      }
    }, 1000)

    return NextResponse.json({ 
      success: true, 
      message: 'API added successfully',
      apiId: result.lastID 
    })
  } catch (error) {
    return NextResponse.json({ error: 'Failed to add API' }, { status: 500 })
  }
}
