import { NextResponse } from 'next/server'
import { MonitoringService } from '@/lib/monitoring'

export async function GET() {
  try {
    const monitoring = MonitoringService.getInstance()
    const health = await monitoring.checkSystemHealth()
    
    return NextResponse.json({
      status: 'healthy',
      uptime: process.uptime(),
      health
    })
  } catch (error) {
    return NextResponse.json({
      status: 'unhealthy',
      error: error.message
    }, { status: 500 })
  }
}
