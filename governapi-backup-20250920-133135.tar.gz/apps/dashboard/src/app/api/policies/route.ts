import { NextRequest, NextResponse } from 'next/server'
import { getDatabase } from '../../../../lib/database/connection'
import jwt from 'jsonwebtoken'

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production'

function getUserFromToken(req: NextRequest) {
  const token = req.cookies.get('auth-token')?.value
  if (!token) return null
  
  try {
    return jwt.verify(token, JWT_SECRET) as any
  } catch {
    return null
  }
}

export async function GET(req: NextRequest) {
  try {
    const user = getUserFromToken(req)
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const db = await getDatabase()
    const policies = await db.all('SELECT * FROM policies WHERE user_id = ? ORDER BY created_at DESC', [user.userId])
    
    return NextResponse.json({ policies })
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch policies' }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  try {
    const user = getUserFromToken(req)
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { name, description, rules } = await req.json()
    
    if (!name || !description) {
      return NextResponse.json({ error: 'Name and description required' }, { status: 400 })
    }

    // Create default policy rules if none provided
    const defaultRules = {
      rateLimit: { requests: 1000, timeWindow: 3600 },
      authentication: { required: true },
      allowedMethods: ['GET', 'POST', 'PUT', 'DELETE'],
      cors: { enabled: true, origins: ['*'] }
    }

    const policyRules = rules || defaultRules

    const db = await getDatabase()
    const result = await db.run(
      'INSERT INTO policies (name, description, policy_rules, user_id) VALUES (?, ?, ?, ?)',
      [name, description, JSON.stringify(policyRules), user.userId]
    )

    return NextResponse.json({ 
      success: true, 
      message: 'Policy created successfully',
      policyId: result.lastID,
      rules: policyRules
    })
  } catch (error) {
    return NextResponse.json({ error: 'Failed to create policy' }, { status: 500 })
  }
}
