import { NextRequest, NextResponse } from 'next/server'
import { supabase } from '@/lib/db/supabase'

export async function POST(req: NextRequest) {
  try {
    const { apiId } = await req.json()
    
    // Get API details
    const { data: api } = await supabase
      .from('apis')
      .select('*')
      .eq('id', apiId)
      .single()
    
    if (!api) throw new Error('API not found')
    
    // Classify based on endpoint patterns
    let classification = 'internal'
    const endpoint = api.endpoint.toLowerCase()
    
    if (endpoint.includes('payment') || endpoint.includes('billing')) {
      classification = 'critical'
    } else if (endpoint.includes('auth') || endpoint.includes('user')) {
      classification = 'sensitive'
    } else if (endpoint.includes('public') || endpoint.includes('open')) {
      classification = 'public'
    }
    
    // Update classification
    await supabase
      .from('apis')
      .update({ classification })
      .eq('id', apiId)
    
    return NextResponse.json({ success: true, classification })
  } catch (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
