import { NextRequest, NextResponse } from 'next/server'
import { supabase } from '@/lib/db/supabase'

export async function POST(req: NextRequest) {
  try {
    const { apiId, request } = await req.json()
    
    // Get active policies
    const { data: policies } = await supabase
      .from('policies')
      .select('*')
      .eq('enabled', true)
    
    const violations = []
    
    for (const policy of policies || []) {
      const rules = policy.rules || {}
      
      // Check authentication requirement
      if (rules.require === 'authentication' && !request.headers?.authorization) {
        violations.push({
          policy_id: policy.id,
          policy_name: policy.name,
          severity: policy.severity,
          message: 'Authentication required'
        })
      }
      
      // Check rate limits
      if (rules.rateLimit && request.requestCount > rules.rateLimit) {
        violations.push({
          policy_id: policy.id,
          policy_name: policy.name,
          severity: policy.severity,
          message: `Rate limit exceeded: ${request.requestCount}/${rules.rateLimit}`
        })
      }
      
      // Check allowed methods
      if (rules.methods && !rules.methods.includes(request.method)) {
        violations.push({
          policy_id: policy.id,
          policy_name: policy.name,
          severity: policy.severity,
          message: `Method ${request.method} not allowed`
        })
      }
    }
    
    // Save violations
    for (const violation of violations) {
      await supabase
        .from('violations')
        .insert({
          api_id: apiId,
          policy_name: violation.policy_name,
          severity: violation.severity,
          details: violation
        })
    }
    
    const blocked = violations.some(v => v.severity === 'critical')
    
    return NextResponse.json({ 
      allowed: !blocked, 
      violations,
      action: blocked ? 'BLOCK' : 'ALLOW'
    })
  } catch (error) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 })
  }
}
