import { threatService } from '@/lib/services/threat-service'

export async function POST(req: Request) {
  try {
    const { ip, reason, duration, threatLevel, threats } = await req.json()
    
    console.log('WEBHOOK: Received threat block request for IP:', ip)
    
    await threatService.saveBlockedIP(ip, reason, duration, threatLevel, threats)
    
    console.log('WEBHOOK: Successfully saved threat to database:', ip)
    return Response.json({ success: true })
  } catch (error) {
    console.error('WEBHOOK: Failed to save threat:', error.message)
    return Response.json({ error: error.message }, { status: 500 })
  }
}
