import { NextRequest, NextResponse } from 'next/server'

async function sendWebhook(webhook: any, payload: any) {
  try {
    let formattedPayload = payload
    
    // Format payload based on webhook type
    if (webhook.type === 'slack') {
      formattedPayload = {
        text: `🚨 GovernAPI Security Alert`,
        attachments: [{
          color: payload.severity === 'CRITICAL' ? 'danger' : payload.severity === 'HIGH' ? 'warning' : 'good',
          fields: [
            { title: 'Target', value: payload.target, short: true },
            { title: 'Vulnerabilities', value: payload.vulnerability_count, short: true },
            { title: 'Risk Level', value: payload.overall_risk, short: true },
            { title: 'Timestamp', value: new Date(payload.timestamp).toLocaleString(), short: true }
          ]
        }]
      }
    }
    
    const response = await fetch(webhook.url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...webhook.headers
      },
      body: JSON.stringify(formattedPayload)
    })
    
    return response.ok
  } catch (error) {
    console.error(`Webhook ${webhook.id} failed:`, error)
    return false
  }
}

export async function POST(req: NextRequest) {
  try {
    const { event_type, data } = await req.json()
    
    const webhooks = global.webhookConfigs || []
    const activeWebhooks = webhooks.filter(w => w.enabled && w.events.includes(event_type))
    
    let successCount = 0
    
    for (const webhook of activeWebhooks) {
      const success = await sendWebhook(webhook, data)
      if (success) successCount++
    }
    
    return NextResponse.json({
      success: true,
      webhooks_triggered: successCount,
      total_webhooks: activeWebhooks.length
    })
    
  } catch (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
