import { NextRequest, NextResponse } from 'next/server'

interface WebhookConfig {
  id: string
  name: string
  url: string
  type: 'slack' | 'discord' | 'teams' | 'generic'
  events: string[]
  enabled: boolean
  headers?: Record<string, string>
  created_at: string
}

export async function POST(req: NextRequest) {
  try {
    const { name, url, type, events = ['security_scan', 'vulnerability_found'] } = await req.json()
    
    if (!name || !url) {
      return NextResponse.json({ error: 'Name and URL are required' }, { status: 400 })
    }
    
    const webhookConfig: WebhookConfig = {
      id: `webhook_${Date.now()}`,
      name,
      url,
      type,
      events,
      enabled: true,
      created_at: new Date().toISOString()
    }
    
    // Store webhook configuration
    if (typeof global !== 'undefined') {
      if (!global.webhookConfigs) global.webhookConfigs = []
      global.webhookConfigs.push(webhookConfig)
    }
    
    return NextResponse.json({
      success: true,
      webhook: webhookConfig
    })
    
  } catch (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}

export async function GET() {
  try {
    const webhooks = global.webhookConfigs || []
    return NextResponse.json({ webhooks })
  } catch (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
