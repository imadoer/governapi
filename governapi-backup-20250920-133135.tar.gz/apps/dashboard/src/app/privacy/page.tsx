'use client'

import { useRouter } from 'next/navigation'
import { Button, Layout, Typography } from 'antd'
import { ArrowLeftOutlined } from '@ant-design/icons'

const { Header, Content } = Layout
const { Title, Paragraph } = Typography

export default function PrivacyPolicy() {
  const router = useRouter()

  return (
    <Layout className="min-h-screen bg-white">
      <Header className="bg-slate-900 px-8">
        <div className="max-w-4xl mx-auto flex items-center justify-between h-full">
          <Button 
            type="text" 
            icon={<ArrowLeftOutlined />} 
            onClick={() => router.push('/')}
            className="text-white hover:text-blue-400"
          >
            Back to Home
          </Button>
        </div>
      </Header>

      <Content className="max-w-4xl mx-auto px-8 py-12">
        <Title level={1} className="mb-8">Privacy Policy</Title>
        <Paragraph className="text-sm text-gray-500 mb-8">
          Last updated: September 13, 2025
        </Paragraph>

        <div className="space-y-8">
          <section>
            <Title level={2}>Information We Collect</Title>
            <Title level={3}>Account Information</Title>
            <Paragraph>
              When you create a GovernAPI account, we collect your name, email address, 
              company name, and other contact information you provide.
            </Paragraph>

            <Title level={3}>API Data</Title>
            <Paragraph>
              We collect metadata about your APIs including endpoints, request patterns, 
              security events, and performance metrics. We do not store the actual content 
              of API requests or responses unless explicitly configured for security analysis.
            </Paragraph>

            <Title level={3}>Usage Information</Title>
            <Paragraph>
              We automatically collect information about how you use our service, including 
              log data, device information, and interaction patterns with our platform.
            </Paragraph>
          </section>

          <section>
            <Title level={2}>How We Use Your Information</Title>
            <ul className="list-disc pl-6 space-y-2">
              <li>Provide and maintain our API security and governance services</li>
              <li>Monitor and analyze API security threats and vulnerabilities</li>
              <li>Generate compliance reports and security analytics</li>
              <li>Communicate with you about service updates and security alerts</li>
              <li>Improve our platform and develop new features</li>
              <li>Ensure the security and integrity of our services</li>
            </ul>
          </section>

          <section>
            <Title level={2}>Data Security</Title>
            <Paragraph>
              We implement industry-standard security measures to protect your data, including:
            </Paragraph>
            <ul className="list-disc pl-6 space-y-2">
              <li>Encryption of data in transit and at rest using AES-256</li>
              <li>Multi-factor authentication for all admin access</li>
              <li>Regular security audits and penetration testing</li>
              <li>SOC2 Type II compliance certification</li>
              <li>Role-based access controls and audit logging</li>
            </ul>
          </section>

          <section>
            <Title level={2}>Data Retention</Title>
            <Paragraph>
              We retain your data for as long as your account is active and as needed to provide 
              services. Security event data is retained according to your subscription plan 
              (30 days for Starter, 90 days for Professional, 2 years for Enterprise).
            </Paragraph>
          </section>

          <section>
            <Title level={2}>Third-Party Integrations</Title>
            <Paragraph>
              GovernAPI integrates with third-party services including Slack, SIEM platforms, 
              and cloud providers. Data shared with these services is governed by their respective 
              privacy policies and our Data Processing Agreements.
            </Paragraph>
          </section>

          <section>
            <Title level={2}>Your Rights</Title>
            <Paragraph>
              Under GDPR and other applicable privacy laws, you have the right to:
            </Paragraph>
            <ul className="list-disc pl-6 space-y-2">
              <li>Access your personal data and receive a copy</li>
              <li>Correct inaccurate or incomplete data</li>
              <li>Delete your personal data (right to be forgotten)</li>
              <li>Object to or restrict processing of your data</li>
              <li>Data portability to another service provider</li>
            </ul>
          </section>

          <section>
            <Title level={2}>Contact Us</Title>
            <Paragraph>
              For privacy-related questions or to exercise your rights, contact us at:
            </Paragraph>
            <Paragraph>
              Email: privacy@governapi.com<br />
              Address: [Your Company Address]<br />
              Phone: [Your Phone Number]
            </Paragraph>
          </section>
        </div>
      </Content>
    </Layout>
  )
}
