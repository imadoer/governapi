import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { AntdRegistry } from '@ant-design/nextjs-registry'
import { AuthProvider } from '@/components/SessionProvider'

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "GovernAPI - API Governance Platform",
  description: "Complete API Governance & Security Platform",
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <AuthProvider>
          <AntdRegistry>{children}</AntdRegistry>
        </AuthProvider>
      </body>
    </html>
  )
}
