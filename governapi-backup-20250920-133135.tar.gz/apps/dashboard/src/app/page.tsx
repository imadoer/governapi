'use client'
import { useRouter } from 'next/navigation'
import { Button, Layout, Menu, Typography, Row, Col, Card, Space, Statistic, Divider ,message} from 'antd'
import { 
  SecurityScanOutlined, 
  ApiOutlined,
  DashboardOutlined,
  FileProtectOutlined,
  LineChartOutlined,
  DollarOutlined,
  CheckCircleOutlined,
  RightOutlined,
  GithubOutlined,
  LinkedinOutlined,
  TwitterOutlined,
  GlobalOutlined,
  SafetyCertificateOutlined,
  ArrowRightOutlined,
  ThunderboltOutlined,
  RocketOutlined
} from '@ant-design/icons'
import { Logo } from '@/components/Logo'

const { Header, Content, Footer } = Layout
const { Title, Paragraph, Text } = Typography

export default function Home() {
  const router = useRouter()
  
  const features = [
    {
      icon: <ApiOutlined className="text-blue-600" style={{ fontSize: '48px' }} />,
      title: 'API Discovery & Inventory',
      description: 'Automatically discover and catalog all APIs across your organization',
      benefits: ['Auto-classification', 'Dependency mapping', 'Version tracking']
    },
    {
      icon: <SecurityScanOutlined className="text-purple-600" style={{ fontSize: '48px' }} />,
      title: 'Security Scanning',
      description: 'Real-time vulnerability detection, bot protection, and threat analysis',
      benefits: ['OWASP compliance', 'Bot detection', 'Threat prevention']
    },
    {
      icon: <FileProtectOutlined className="text-green-600" style={{ fontSize: '48px' }} />,
      title: 'Policy Engine',
      description: 'Define and enforce governance policies with pre-built templates',
      benefits: ['Real-time enforcement', 'Custom rules', 'Policy testing']
    },
    {
      icon: <SafetyCertificateOutlined className="text-orange-600" style={{ fontSize: '48px' }} />,
      title: 'Compliance Automation',
      description: 'Built-in templates for SOC2, GDPR, PCI-DSS, HIPAA, and ISO 27001',
      benefits: ['Automated reports', 'Audit trails', 'Gap analysis']
    },
    {
      icon: <DollarOutlined className="text-emerald-600" style={{ fontSize: '48px' }} />,
      title: 'Cost Analytics',
      description: 'Track API usage costs, identify waste, and calculate security ROI',
      benefits: ['Usage tracking', 'Cost allocation', 'ROI dashboard']
    },
    {
      icon: <LineChartOutlined className="text-indigo-600" style={{ fontSize: '48px' }} />,
      title: 'Governance Metrics',
      description: 'Maturity scoring, compliance tracking, and executive dashboards',
      benefits: ['KPI tracking', 'Trend analysis', 'Custom reports']
    }
  ]

  const stats = [
    { value: '50M+', label: 'API Calls Analyzed Daily' },
    { value: '99.9%', label: 'Threat Detection Accuracy' },
    { value: '73%', label: 'Average Cost Savings' },
    { value: '24/7', label: 'Continuous Monitoring' }
  ]

  const complianceLogos = [
    { name: 'SOC2', color: '#1890ff' },
    { name: 'GDPR', color: '#52c41a' },
    { name: 'PCI-DSS', color: '#fa8c16' },
    { name: 'HIPAA', color: '#722ed1' },
    { name: 'ISO 27001', color: '#eb2f96' },
    { name: 'NIST', color: '#13c2c2' }
  ]

  return (
    <Layout className="min-h-screen bg-white">
      {/* Header */}
      <Header className="fixed w-full z-50 bg-white/95 backdrop-blur shadow-sm h-16">
        <div className="max-w-7xl mx-auto px-4 flex justify-between items-center h-full">
          <div className="flex items-center">
            <Logo size={36} className="mr-8" light={true} />
            <nav className="hidden md:flex items-center space-x-8">
              <button onClick={() => window.scrollTo({top: 0, behavior: "smooth"})} className="text-gray-700 hover:text-blue-600 font-medium transition-colors">Home</button>
              <button onClick={() => alert("Platform section coming soon")} className="text-gray-700 hover:text-blue-600 font-medium transition-colors">Platform</button>
              <button onClick={() => alert("Solutions section coming soon")} className="text-gray-700 hover:text-blue-600 font-medium transition-colors">Solutions</button>
              <button onClick={() => router.push("/pricing")} className="text-gray-700 hover:text-blue-600 font-medium transition-colors">Pricing</button>
              <button onClick={() => alert("Documentation coming soon")} className="text-gray-700 hover:text-blue-600 font-medium transition-colors">Documentation</button>
              <button onClick={() => { console.log("Blog clicked"); router.push("/blog"); }} className="text-gray-700 hover:text-blue-600 font-medium transition-colors">Blog</button>
            </nav>
          </div>
          <Space className="hidden sm:flex">
            <Button onClick={() => router.push('/login')}>Sign In</Button>
            <Button type="primary" onClick={() => router.push('/dashboard')}>
              Dashboard
            </Button>
          </Space>
        </div>
      </Header>

      <Content className="mt-16">
        {/* Hero Section */}
        <section className="relative overflow-hidden bg-gradient-to-br from-blue-50 via-white to-purple-50 py-24">
          <div className="absolute inset-0 bg-grid-pattern opacity-5"></div>
          <div className="max-w-7xl mx-auto px-4 text-center relative z-10">
            <div className="inline-flex items-center gap-2 bg-blue-50 rounded-full px-4 py-2 mb-6">
              <ThunderboltOutlined className="text-blue-600" />
              <Text className="text-blue-700 font-medium">Enterprise-Ready API Governance Platform</Text>
            </div>
            <Title level={1} className="text-5xl lg:text-6xl mb-6 bg-gradient-to-r from-gray-900 to-gray-600 bg-clip-text text-transparent">
              Complete API Governance & Security Platform
            </Title>
            <Paragraph className="text-xl max-w-3xl mx-auto mb-8 text-gray-600 leading-relaxed">
              Discover, secure, and govern all your APIs from a single platform. 
              Automate compliance, enforce policies, and reduce costs while ensuring 
              enterprise-grade security across your API ecosystem.
            </Paragraph>
            <Space size="large" className="mb-8">
              <Button 
                type="primary" 
                size="large" 
                icon={<RocketOutlined />}
                onClick={() => router.push('/demo')}
                className="h-12 px-8 text-lg shadow-lg hover:shadow-xl transition-shadow"
              >
                Request Demo
              </Button>
              <Button 
                size="large"
                type="default"
                onClick={() => router.push('/dashboard')}
                className="h-12 px-8 text-lg border-2"
              >
                Try Free
              </Button>
            </Space>
            <div>
              <Text type="secondary">Trusted by enterprises managing 1,000+ APIs</Text>
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="py-20 bg-gradient-to-b from-gray-50 to-white">
          <div className="max-w-7xl mx-auto px-4">
            <Row gutter={[32, 32]} justify="center">
              {stats.map((stat, index) => (
                <Col key={index} xs={12} sm={6}>
                  <div className="text-center transform hover:scale-105 transition-transform">
                    <Title level={2} className="mb-0 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                      {stat.value}
                    </Title>
                    <Text className="text-gray-600 font-medium">{stat.label}</Text>
                  </div>
                </Col>
              ))}
            </Row>
          </div>
        </section>

        {/* Features Grid */}
        <section className="py-24 bg-white">
          <div className="max-w-7xl mx-auto px-4">
            <div className="text-center mb-16">
              <Title level={2} className="text-4xl mb-4">Everything You Need for API Governance</Title>
              <Paragraph className="text-xl text-gray-600 max-w-2xl mx-auto">
                A unified platform that brings together discovery, security, compliance, and analytics
              </Paragraph>
            </div>
            <Row gutter={[32, 32]}>
              {features.map((feature, index) => (
                <Col key={index} xs={24} sm={12} lg={8}>
                  <Card 
                    bordered={false} 
                    className="h-full hover:shadow-2xl transition-all duration-300 group cursor-pointer"
                    hoverable
                  >
                    <div className="mb-4 transform group-hover:scale-110 transition-transform">
                      {feature.icon}
                    </div>
                    <Title level={4} className="mb-3">{feature.title}</Title>
                    <Paragraph className="text-gray-600 mb-4">
                      {feature.description}
                    </Paragraph>
                    <ul className="space-y-2">
                      {feature.benefits.map((benefit, idx) => (
                        <li key={idx} className="flex items-center text-gray-500">
                          <CheckCircleOutlined className="text-green-500 mr-2" />
                          <Text className="text-sm">{benefit}</Text>
                        </li>
                      ))}
                    </ul>
                  </Card>
                </Col>
              ))}
            </Row>
          </div>
        </section>

        {/* Platform Overview */}
        <section className="py-24 bg-gradient-to-r from-blue-50 to-purple-50">
          <div className="max-w-7xl mx-auto px-4">
            <Row gutter={[48, 48]} align="middle">
              <Col xs={24} lg={12}>
                <Title level={2} className="text-4xl mb-6">Complete API Lifecycle Management</Title>
                <Paragraph className="text-lg mb-8 text-gray-600">
                  GovernAPI provides end-to-end governance across your entire API ecosystem with powerful automation and insights.
                </Paragraph>
                <div className="space-y-6">
                  {[
                    { title: 'Discovery & Classification', desc: 'Automatically find and classify APIs based on data sensitivity' },
                    { title: 'Real-time Security', desc: 'Continuous scanning for vulnerabilities and threats' },
                    { title: 'Policy Enforcement', desc: 'Define once, enforce everywhere with our policy engine' },
                    { title: 'Compliance Reporting', desc: 'Automated reports for auditors and executives' }
                  ].map((item, idx) => (
                    <div key={idx} className="flex items-start group">
                      <div className="w-12 h-12 rounded-lg bg-blue-100 flex items-center justify-center mr-4 group-hover:bg-blue-600 transition-colors">
                        <CheckCircleOutlined className="text-blue-600 text-lg group-hover:text-white" />
                      </div>
                      <div>
                        <Text strong className="text-lg">{item.title}</Text>
                        <br />
                        <Text className="text-gray-600">{item.desc}</Text>
                      </div>
                    </div>
                  ))}
                </div>
              </Col>
              <Col xs={24} lg={12}>
                <div className="bg-white rounded-2xl shadow-2xl p-2">
                  <div className="bg-gradient-to-br from-gray-100 to-gray-200 rounded-xl p-8 h-96 flex items-center justify-center">
                    <div className="text-center">
                      <DashboardOutlined style={{ fontSize: '64px', color: '#8c8c8c' }} />
                      <Title level={4} className="mt-4 text-gray-600">Dashboard Preview</Title>
                      <Text type="secondary">Live dashboard screenshot coming soon</Text>
                    </div>
                  </div>
                </div>
              </Col>
            </Row>
          </div>
        </section>

        {/* Compliance Section */}
        <section className="py-24 bg-white">
          <div className="max-w-7xl mx-auto px-4 text-center">
            <Title level={2} className="text-4xl mb-4">Built for Enterprise Compliance</Title>
            <Paragraph className="text-xl mb-16 text-gray-600">
              Pre-built policy templates for major compliance frameworks
            </Paragraph>
            <Row gutter={[24, 24]} justify="center">
              {complianceLogos.map((framework, index) => (
                <Col key={index} xs={12} sm={8} md={4}>
                  <div className="bg-gray-50 rounded-xl p-6 hover:shadow-lg transition-all transform hover:scale-105 cursor-pointer">
                    <div className="w-16 h-16 mx-auto mb-3 rounded-full flex items-center justify-center" 
                         style={{ backgroundColor: `${framework.color}20` }}>
                      <SafetyCertificateOutlined style={{ fontSize: '32px', color: framework.color }} />
                    </div>
                    <Title level={5} className="mb-0" style={{ color: framework.color }}>
                      {framework.name}
                    </Title>
                  </div>
                </Col>
              ))}
            </Row>
          </div>
        </section>

        {/* ROI Section */}
        <section className="py-24 bg-gradient-to-r from-blue-600 to-purple-600 text-white relative overflow-hidden">
          <div className="absolute inset-0 bg-grid-pattern opacity-10"></div>
          <div className="max-w-4xl mx-auto px-4 text-center relative z-10">
            <Title level={2} className="text-white text-4xl mb-8">
              Measurable ROI from Day One
            </Title>
            <Row gutter={[48, 32]} className="mb-12">
              <Col xs={24} sm={8}>
                <div className="transform hover:scale-105 transition-transform">
                  <Statistic 
                    value={73} 
                    suffix="%" 
                    valueStyle={{ color: 'white', fontSize: '48px' }}
                    className="text-white"
                  />
                  <Text className="text-blue-100 text-lg">Reduction in API security incidents</Text>
                </div>
              </Col>
              <Col xs={24} sm={8}>
                <div className="transform hover:scale-105 transition-transform">
                  <Statistic 
                    value={4.2} 
                    suffix="x" 
                    valueStyle={{ color: 'white', fontSize: '48px' }}
                  />
                  <Text className="text-blue-100 text-lg">Faster compliance audits</Text>
                </div>
              </Col>
              <Col xs={24} sm={8}>
                <div className="transform hover:scale-105 transition-transform">
                  <Statistic 
                    value={31} 
                    suffix="%" 
                    valueStyle={{ color: 'white', fontSize: '48px' }}
                  />
                  <Text className="text-blue-100 text-lg">Lower API infrastructure costs</Text>
                </div>
              </Col>
            </Row>
            <Button 
              size="large" 
              type="default"
              className="h-12 px-8 text-lg border-2 hover:bg-white hover:text-blue-600"
              onClick={() => router.push('/roi-calculator')}
            >
              Calculate Your ROI <ArrowRightOutlined />
            </Button>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-24 bg-gray-50">
          <div className="max-w-4xl mx-auto px-4 text-center">
            <Title level={2} className="text-4xl mb-6">
              Ready to Take Control of Your APIs?
            </Title>
            <Paragraph className="text-xl mb-12 text-gray-600">
              Join leading enterprises using GovernAPI to secure and govern their API ecosystem
            </Paragraph>
            <Space size="large">
              <Button 
                type="primary"
                size="large" 
                className="h-12 px-8 text-lg shadow-lg hover:shadow-xl"
                icon={<RocketOutlined />}
                onClick={() => router.push('/demo')}
              >
                Schedule Demo
              </Button>
              <Button 
                size="large"
                className="h-12 px-8 text-lg"
                onClick={() => router.push('/contact')}
              >
                Contact Sales
              </Button>
            </Space>
          </div>
        </section>
      </Content>

      <Footer className="bg-gray-900 text-white">
        <div className="max-w-7xl mx-auto px-4 py-16">
          <Row gutter={[32, 48]}>
            <Col xs={24} sm={12} lg={6}>
              <Logo size={32} className="mb-4 text-white" />
              <Paragraph className="text-gray-400">
                The complete API governance and security platform for modern enterprises.
              </Paragraph>
              <Space size="large" className="mt-4">
                <GithubOutlined className="text-2xl hover:text-blue-400 cursor-pointer transition-colors" />
                <TwitterOutlined className="text-2xl hover:text-blue-400 cursor-pointer transition-colors" />
                <LinkedinOutlined className="text-2xl hover:text-blue-400 cursor-pointer transition-colors" />
              </Space>
            </Col>
            <Col xs={24} sm={12} lg={6}>
              <Title level={5} className="text-white mb-4">Platform</Title>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">API Discovery</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Security Scanning</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Policy Engine</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Compliance</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Analytics</a></li>
              </ul>
            </Col>
            <Col xs={24} sm={12} lg={6}>
              <Title level={5} className="text-white mb-4">Solutions</Title>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Financial Services</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Healthcare</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Technology</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Retail</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Government</a></li>
              </ul>
            </Col>
            <Col xs={24} sm={12} lg={6}>
              <Title level={5} className="text-white mb-4">Resources</Title>
              <ul className="space-y-2">
                <li><a href="/terms" className="text-gray-400 hover:text-white transition-colors">Terms of Service</a></li>
                <li><a href="/privacy" className="text-gray-400 hover:text-white transition-colors">Privacy Policy</a></li>
                <li><a href="/blog" className="text-gray-400 hover:text-white transition-colors">API Reference</a></li>
                <li><a href="/blog" className="text-gray-400 hover:text-white transition-colors">Blog</a></li>
                <li><a href="/contact" className="text-gray-400 hover:text-white transition-colors">Support</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Status</a></li>
              </ul>
            </Col>
          </Row>
          <Divider className="my-8 bg-gray-800" />
          <div className="text-center text-gray-400">
            <Text>© 2024 GovernAPI. All rights reserved.</Text>
            <span className="mx-4">•</span>
            <a href="#" className="text-gray-400 hover:text-white transition-colors">Privacy Policy</a>
            <span className="mx-4">•</span>
            <a href="#" className="text-gray-400 hover:text-white transition-colors">Terms of Service</a>
                <li><a href="/privacy" className="text-gray-400 hover:text-white transition-colors">Privacy Policy</a></li>
          </div>
        </div>
      </Footer>
    </Layout>
  )
}
