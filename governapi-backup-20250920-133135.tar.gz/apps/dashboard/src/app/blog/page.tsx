'use client'

import { useRouter } from 'next/navigation'
import { Button, Layout, Card, Row, Col, Typography, Space, Tag } from 'antd'
import { ArrowLeftOutlined, CalendarOutlined, UserOutlined, ArrowRightOutlined } from '@ant-design/icons'

const { Header, Content } = Layout
const { Title, Paragraph, Text } = Typography

export default function BlogPage() {
  const router = useRouter()

  const blogPosts = [
    {
      id: 1,
      title: "API Security Trends 2025: What Enterprises Need to Know",
      excerpt: "The API security landscape is evolving rapidly as enterprises adopt API-first architectures. With 91% of organizations experiencing API-related security incidents in 2024...",
      author: "GovernAPI Team",
      date: "September 13, 2025",
      readTime: "8 min read",
      tags: ["API Security", "Trends", "Enterprise"],
      slug: "api-security-trends-2025"
    },
    {
      id: 2, 
      title: "Beyond Postman: Why Enterprise API Governance Requires Purpose-Built Solutions",
      excerpt: "While Postman revolutionized API development and testing, enterprises are discovering its limitations for production security and governance...",
      author: "GovernAPI Team",
      date: "September 12, 2025", 
      readTime: "6 min read",
      tags: ["API Governance", "Enterprise", "Postman"],
      slug: "beyond-postman-enterprise-api-governance"
    },
    {
      id: 3,
      title: "Salt Security vs GovernAPI: A CTO's Perspective on API Security Platform Selection",
      excerpt: "With Salt Security's $1.4B valuation highlighting market demand, enterprises are evaluating API security platforms more seriously than ever...",
      author: "GovernAPI Team", 
      date: "September 11, 2025",
      readTime: "10 min read",
      tags: ["Competitive Analysis", "Salt Security", "CTO"],
      slug: "salt-security-vs-governapi-comparison"
    }
  ]

  return (
    <Layout className="min-h-screen bg-white">
      <Header className="bg-slate-900 px-8">
        <div className="max-w-6xl mx-auto flex items-center justify-between h-full">
          <Button 
            type="text" 
            icon={<ArrowLeftOutlined />} 
            onClick={() => router.push('/')}
            className="text-white hover:text-blue-400"
          >
            Back to Home
          </Button>
          <div className="text-white font-bold text-xl">GovernAPI Blog</div>
        </div>
      </Header>

      <Content className="max-w-6xl mx-auto px-8 py-12">
        <div className="text-center mb-16">
          <Title level={1} className="text-4xl font-bold mb-4">
            API Security Insights & Trends
          </Title>
          <Paragraph className="text-lg text-gray-600 max-w-2xl mx-auto">
            Stay ahead of the API security curve with expert insights, industry analysis, 
            and practical guidance for enterprise security teams.
          </Paragraph>
        </div>

        <Row gutter={[32, 32]}>
          {blogPosts.map((post) => (
            <Col xs={24} lg={8} key={post.id}>
              <Card 
                hoverable
                className="h-full shadow-lg border-0"
                onClick={() => router.push(`/blog/${post.slug}`)}
              >
                <div className="mb-4">
                  <Space wrap>
                    {post.tags.map(tag => (
                      <Tag key={tag} color="blue">{tag}</Tag>
                    ))}
                  </Space>
                </div>
                
                <Title level={3} className="mb-3 text-xl">
                  {post.title}
                </Title>
                
                <Paragraph className="text-gray-600 mb-4">
                  {post.excerpt}
                </Paragraph>
                
                <div className="flex justify-between items-center text-sm text-gray-500">
                  <Space>
                    <UserOutlined />
                    <span>{post.author}</span>
                  </Space>
                  <Space>
                    <CalendarOutlined />
                    <span>{post.date}</span>
                    <span>•</span>
                    <span>{post.readTime}</span>
                  </Space>
                </div>
                
                <Button 
                  type="link" 
                  icon={<ArrowRightOutlined />}
                  className="mt-4 px-0"
                >
                  Read More
                </Button>
              </Card>
            </Col>
          ))}
        </Row>

        <div className="text-center mt-16">
          <Title level={2} className="mb-4">Ready to Secure Your APIs?</Title>
          <Paragraph className="text-lg text-gray-600 mb-6">
            Get started with GovernAPI's comprehensive API security platform
          </Paragraph>
          <Space size="large">
            <Button size="large" onClick={() => router.push('/dashboard')}>
              View Dashboard
            </Button>
            <Button type="primary" size="large" onClick={() => router.push('/login')}>
              Start Free Trial
            </Button>
          </Space>
        </div>
      </Content>
    </Layout>
  )
}
