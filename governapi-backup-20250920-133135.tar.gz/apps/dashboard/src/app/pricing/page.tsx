'use client'

import { useRouter } from 'next/navigation'
import { Button, Layout, Typography, Card, Row, Col, Space } from 'antd'
import { ArrowLeftOutlined, CheckOutlined } from '@ant-design/icons'

const { Header, Content } = Layout
const { Title, Paragraph } = Typography

export default function PricingPage() {
  const router = useRouter()

  const plans = [
    {
      name: "Starter",
      price: "$2,500",
      period: "/month",
      description: "Perfect for small-medium enterprises",
      features: [
        "Up to 200 APIs monitored",
        "Basic security scanning",
        "Standard compliance reports (SOC2, GDPR)",
        "Email alerts",
        "8x5 support",
        "30-day data retention"
      ],
      cta: "Start Free Trial",
      popular: false
    },
    {
      name: "Professional",
      price: "$8,500",
      period: "/month",
      description: "Ideal for mid-market enterprises",
      features: [
        "Up to 1000 APIs monitored",
        "Advanced threat detection",
        "Real-time bot protection",
        "Advanced compliance automation",
        "Slack/Teams integration",
        "Custom reporting",
        "12x5 support",
        "90-day data retention"
      ],
      cta: "Request Demo",
      popular: true
    },
    {
      name: "Enterprise",
      price: "$25,000",
      period: "/month",
      description: "For large enterprises with unlimited needs",
      features: [
        "Unlimited APIs",
        "AI-powered threat intelligence",
        "Custom policy engine",
        "Advanced analytics & reporting",
        "Full SIEM integration",
        "Dedicated customer success manager",
        "24x7 premium support",
        "2-year data retention",
        "On-premise deployment option"
      ],
      cta: "Contact Sales",
      popular: false
    }
  ]

  return (
    <Layout className="min-h-screen bg-gray-50">
      <Header className="bg-slate-900 px-8">
        <div className="max-w-6xl mx-auto flex items-center justify-between h-full">
          <Button 
            type="text" 
            icon={<ArrowLeftOutlined />} 
            onClick={() => router.push('/')}
            className="text-white hover:text-blue-400"
          >
            Back to Home
          </Button>
        </div>
      </Header>

      <Content className="max-w-6xl mx-auto px-8 py-16">
        <div className="text-center mb-16">
          <Title level={1} className="text-4xl font-bold mb-4">
            Simple, Transparent Pricing
          </Title>
          <Paragraph className="text-xl text-gray-600">
            Choose the plan that fits your organization's API security needs
          </Paragraph>
        </div>

        <Row gutter={[32, 32]} justify="center">
          {plans.map((plan, index) => (
            <Col xs={24} lg={8} key={index}>
              <Card 
                className={`h-full shadow-lg ${plan.popular ? 'border-2 border-blue-500' : ''}`}
                style={{ position: 'relative' }}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-blue-500 text-white px-4 py-1 rounded-full text-sm font-medium">
                    Most Popular
                  </div>
                )}
                
                <div className="text-center mb-6">
                  <Title level={2} className="mb-2">{plan.name}</Title>
                  <div className="mb-2">
                    <span className="text-4xl font-bold">{plan.price}</span>
                    <span className="text-gray-500">{plan.period}</span>
                  </div>
                  <Paragraph className="text-gray-600">{plan.description}</Paragraph>
                </div>

                <div className="mb-8">
                  {plan.features.map((feature, idx) => (
                    <div key={idx} className="flex items-center mb-3">
                      <CheckOutlined className="text-green-500 mr-3" />
                      <span>{feature}</span>
                    </div>
                  ))}
                </div>

                <Button 
                  type={plan.popular ? "primary" : "default"}
                  size="large"
                  block
                  onClick={() => router.push('/dashboard')}
                >
                  {plan.cta}
                </Button>
              </Card>
            </Col>
          ))}
        </Row>

        <div className="text-center mt-16">
          <Title level={2} className="mb-4">Calculate Your ROI</Title>
          <Paragraph className="text-lg text-gray-600 mb-6">
            The average data breach costs $4.45M. Our customers see 800%+ ROI annually.
          </Paragraph>
          <Button size="large" onClick={() => router.push('/dashboard')}>
            See ROI Calculator
          </Button>
        </div>
      </Content>
    </Layout>
  )
}
