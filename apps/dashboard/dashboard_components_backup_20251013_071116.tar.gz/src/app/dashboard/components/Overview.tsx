'use client'

import { Card, Row, Col, Progress, Table, Tag, Space, Timeline, Divider, Button } from 'antd'
import { Typography } from 'antd'
import { RiseOutlined, FallOutlined } from '@ant-design/icons'

const { Text, Title } = Typography

export function OverviewTab({ 
  apiInventory, 
  complianceScores, 
  policyViolations, 
  costAnalytics,
  recentActivity 
}: any) {
  return (
    <Row gutter={[16, 16]}>
      {/* API Inventory Summary */}
      <Col xs={24} lg={12}>
        <Card title="API Inventory" extra={<a>View All</a>}>
          <Row gutter={[16, 16]}>
            <Col span={12}>
              <div className="text-center">
                <Progress
                  type="circle"
                  percent={Math.round((apiInventory.classified / apiInventory.total) * 100)}
                  width={120}
                />
                <div className="mt-2">
                  <Text>Classification Status</Text>
                </div>
              </div>
            </Col>
            <Col span={12}>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <Text>Critical APIs:</Text>
                  <Text strong>{apiInventory.critical}</Text>
                </div>
                <div className="flex justify-between">
                  <Text>Internal APIs:</Text>
                  <Text strong>{apiInventory.internal}</Text>
                </div>
                <div className="flex justify-between">
                  <Text>External APIs:</Text>
                  <Text strong>{apiInventory.external}</Text>
                </div>
                <div className="flex justify-between">
                  <Text>Unclassified:</Text>
                  <Text strong type="warning">{apiInventory.unclassified}</Text>
                </div>
              </div>
            </Col>
          </Row>
        </Card>
      </Col>

      {/* Compliance Status */}
      <Col xs={24} lg={12}>
        <Card title="Compliance Status" extra={<a>Configure</a>}>
          <div className="space-y-4">
            {complianceScores.map((framework: any, index: number) => (
              <div key={index}>
                <div className="flex justify-between items-center mb-1">
                  <Text strong>{framework.framework}</Text>
                  <Space>
                    <Text type={framework.trend === 'up' ? 'success' : framework.trend === 'down' ? 'danger' : 'secondary'}>
                      {framework.trend === 'up' ? <RiseOutlined /> : framework.trend === 'down' ? <FallOutlined /> : '-'}
                      {Math.abs(framework.change)}%
                    </Text>
                    <Text strong>{framework.score}%</Text>
                  </Space>
                </div>
                <Progress 
                  percent={framework.score} 
                  strokeColor={framework.score >= 80 ? '#52c41a' : '#faad14'}
                  showInfo={false}
                />
              </div>
            ))}
          </div>
        </Card>
      </Col>

      {/* Policy Violations */}
      <Col xs={24}>
        <Card 
          title="Active Policy Violations" 
          extra={<Space><Button size="small">View All</Button></Space>}
        >
          <Table
            dataSource={policyViolations}
            pagination={false}
            size="small"
            columns={[
              { title: 'ID', dataIndex: 'id', key: 'id', width: 100 },
              { title: 'API', dataIndex: 'api', key: 'api' },
              { title: 'Policy', dataIndex: 'policy', key: 'policy' },
              { 
                title: 'Severity', 
                dataIndex: 'severity', 
                key: 'severity',
                render: (severity: string) => (
                  <Tag color={
                    severity === 'critical' ? 'error' : 
                    severity === 'high' ? 'warning' : 
                    'default'
                  }>
                    {severity.toUpperCase()}
                  </Tag>
                )
              },
              { title: 'Age', dataIndex: 'age', key: 'age' },
              {
                title: 'Action',
                key: 'action',
                render: () => (
                  <Space>
                    <a>Review</a>
                    <a>Exempt</a>
                  </Space>
                )
              }
            ]}
          />
        </Card>
      </Col>

      {/* Cost Analytics */}
      <Col xs={24} lg={12}>
        <Card title="API Cost Analytics" extra={<Text type="secondary">This Month</Text>}>
          <Row gutter={[16, 16]}>
            <Col span={12}>
              <Title level={4}>${costAnalytics.totalMonthly.toLocaleString()}</Title>
              <Text type="secondary">Total API Costs</Text>
            </Col>
            <Col span={12}>
              <Title level={4} style={{ color: '#52c41a' }}>${costAnalytics.savings.toLocaleString()}</Title>
              <Text type="secondary">Cost Savings</Text>
            </Col>
          </Row>
          <Divider />
          <div className="space-y-2">
            <div className="flex justify-between">
              <Text>Legitimate Traffic:</Text>
              <Text>${costAnalytics.legitimate.toLocaleString()}</Text>
            </div>
            <div className="flex justify-between">
              <Text>Suspicious Traffic:</Text>
              <Text type="warning">${costAnalytics.suspicious.toLocaleString()}</Text>
            </div>
            <div className="flex justify-between">
              <Text>Blocked Threats:</Text>
              <Text type="danger">${costAnalytics.blocked.toLocaleString()}</Text>
            </div>
          </div>
        </Card>
      </Col>

      {/* Recent Activity */}
      <Col xs={24} lg={12}>
        <Card title="Recent Activity" extra={<a>View All</a>}>
          <Timeline>
            {recentActivity?.map((activity: any, index: number) => (
              <Timeline.Item 
                key={index}
                color={
                  activity.type === 'security' ? 'red' :
                  activity.type === 'discovery' ? 'blue' :
                  activity.type === 'policy' ? 'orange' :
                  'green'
                }
              >
                <div>
                  <Text type="secondary">{activity.time}</Text>
                  <br />
                  <Text>{activity.event}</Text>
                </div>
              </Timeline.Item>
            ))}
          </Timeline>
        </Card>
      </Col>
    </Row>
  )
}
